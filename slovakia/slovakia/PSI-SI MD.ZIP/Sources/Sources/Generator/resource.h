//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PsiSiGen.rc
//
#define IDR_MAINFRAME                   128
#define IDD_ABOUTBOX                    300
#define IDR_PSISIGTYPE                  329
#define IDD_GenOptions                  330
#define IDD_TablesFreq                  330
#define IDD_PhysInterface               332
#define IDC_PatFreq                     2000
#define IDC_PmtFreq                     2001
#define IDC_SdtFreq                     2002
#define IDC_edtIpPort                   2003
#define IDC_PatSpeed                    2005
#define IDC_PmtSpeed                    2006
#define IDC_SdtSpeed                    2007
#define IDC_NitSpeed                    2008
#define IDC_TotalSpeed                  2009
#define IDC_CatSpeed                    2010
#define IDC_btnDvbAsi                   2012
#define IDC_btnRs422                    2013
#define IDC_btnEthernet                 2014
#define IDC_edtStuffing                 2015
#define IDC_chkNoIbStuffing             2016
#define IDC_edtComergonTest             2017
#define IDC_edtIpAddress                2018
#define IDC_btnUdp                      2019
#define IDC_btnTcp                      2020
#define IDC_edtComergonPort             2021
#define IDC_edtComergonIrq              2022
#define IDC_NitFreq                     2023
#define IDC_CatFreq                     2024
#define IDC_ChangePrgLevel              2024
#define IDC_chkPAT                      2026
#define IDC_chkPMT                      2027
#define IDC_chkSDT                      2028
#define IDC_chkNIT                      2029
#define IDC_chkCAT                      2030
#define IDC_NetInfo                     32771
#define IDC_PrgAssoc                    32772
#define IDC_Start                       32773
#define IDC_Stop                        32774
#define ID_GenOptions                   32775
#define ID_ApplyChanges                 32776
#define ID_OUTPUT_TABLESFREQUENCIES     32777
#define ID_OUTPUT_PHYSICALINTERFACE     32778
#define ID_VIEWEDIT_VIEWRUNNINGPSITABLES 32779
#define ID_VIEWEDIT_VIEWEDITEDPSITABLES 32780
#define ID_VIEWEDIT_VIEWMODIFICATIONS   32781
#define ID_VIEWEDIT_EDITPSITABLES       32782
#define ID_WIZARDS_NEWNEWTWORKWIZARD    32783
#define ID_NewNetworkWizard             32783
#define ID_AddProgramWizard             32784
#define ID_ProgramStreamWizard          32785
#define ID_Device_DvbAsi                32786
#define ID_Device_Dvb                   32787
#define ID_Device_Ethernet              32788
#define ID_FILE_OPEN_DontApply          32790

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        334
#define _APS_NEXT_COMMAND_VALUE         32791
#define _APS_NEXT_CONTROL_VALUE         2028
#define _APS_NEXT_SYMED_VALUE           301
#endif
#endif
