//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by IoDvbAsi.rc
//
#define ID_DvbAsiSetupDlgSrv            101
#define ID_DvbAsiSetupDlgRcv            102
#define IDD_AsiReadmeDlg                103
#define IDD_DvbAsiClienStatDlg          105
#define IDB_MainData                    111
#define IDB_BITMAP1                     112
#define IDC_transSpeed                  1000
#define IDC_RFHigh                      1002
#define IDC_204bytes                    1003
#define IDC_PacSync                     1004
#define IDC_NoIb                        1009
#define IDC_AsiReadmeEdit               1011
#define IDC_AsiServerHelp               1012
#define IDC_AsiClientHelp               1013
#define IDC_NumLost                     1016
#define IDC_NumExErr                    1017
#define IDC_StartDma                    1018
#define IDC_MaxDspIntCount              1019
#define IDC_NumPciAbts                  1020
#define IDC_MinNumPend                  1021
#define IDC_NumPend                     1022
#define IDC_NumInts                     1023
#define IDC_NumFifoErrs                 1024
#define IDC_NumQued                     1025
#define IDC_StaticNumLostI              1027
#define IDC_StaticNumExErr              1028
#define IDC_StaticNumLostI2             1029
#define IDC_StaticNumExErr2             1030
#define IDC_StaticNumLostI3             1031
#define IDC_StaticNumExErr3             1032
#define IDC_StaticNumLostI4             1033
#define IDC_StaticNumExErr4             1034
#define IDC_StaticNumLostI5             1035
#define IDC_StaticNumExErr5             1036

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        113
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1030
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
