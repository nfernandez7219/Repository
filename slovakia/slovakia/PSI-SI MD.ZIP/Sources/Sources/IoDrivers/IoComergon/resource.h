//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by IoComergon.rc
//
#define sClntD_DVBStatistics            251
#define IDC_ViewHelp                    1000
#define IDC_PID                         1001
#define IDC_RADIO_HEX                   1002
#define IDC_MSG                         1003
#define IDC_BASE                        1004
#define IDC_IRQ                         1005
#define IDC_RADIO_DEC                   1006
#define IDC_DataRate                    1007
#define IDC_TESTHW                      1009
#define sClntC_numPacketsAcceptedHW     2151
#define sClntC_numPacketsFilteredHW     2152
#define sClntC_numPacketsLostHW         2153
#define sClntC_numPacketsAcceptedDrv    2155
#define sClntC_numInternetPacketsDrv    2156
#define IDC_STATUS                      2158
#define IDC_BUFFERSIZE                  2159
#define IDC_INAPP                       2160
#define IDC_OUTAPP                      2161
#define sClntC_numPacketsCorruptedHW    2162
#define IDC_INCARD                      2162
#define IDC_OUTCARD                     2163
#define IDC_INPACKETS                   2164
#define IDC_OUTPACKETS                  2165
#define IDC_READ                        2166
#define IDC_WRITE                       2167
#define IDC_PACKETSSENT                 2168
#define IDC_DUMP                        2170
#define sClntC_TimingClockSignal        2177
#define sClntC_CardSynchronization      2178
#define IDC_Version                     2179

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         2180
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
