//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ServStp.rc
//
#define IDI_Bussiness                   200
#define IDI_Phone                       201
#define IDI_Computers                   202
#define sSrvD_ExtCfgDialog              225
#define sSrvD_Scheduler                 226
#define sSrvD_SetupDialog               600
#define sSrvD_DVB                       601
#define sSrvD_Providers                 602
#define sSrvD_Users                     603
#define sSrvD_Channels                  604
#define sSrvD_AdrProvider               605
#define sSrvD_AdrUser                   606
#define sSrvD_ChannelView               607
#define sSrvD_Internet                  608
#define sSrvD_Support                   609
#define sSrvD_AdrTCPProvider            610
#define sSrvD_ProvidersTCP              611
#define sSrvC_AdrName                   1000
#define sSrvC_AdrSurname                1001
#define sSrvC_AdrStreet                 1002
#define sSrvC_AdrZipCode                1003
#define sSrvC_AdrCity                   1004
#define sSrvC_AdrCountry                1005
#define sSrvC_AdrTelephone              1006
#define sSrvC_AdrFax                    1007
#define sSrvC_AdrEMail                  1008
#define sSrvC_AdrContactPerson          1009
#define sSrvC_AdrChannelsList           1010
#define IDC_TCPAddress                  1010
#define sSrvC_AdrHNet                   1011
#define sSrvC_AdrUserID                 1012
#define sSrvC_ChnlPort                  1050
#define sSrvC_ChnlName                  1051
#define sSrvC_ChnlOutRateFrom           1052
#define sSrvC_ChnlOutRateTo             1053
#define sSrvC_ChnlNumRebroad            1054
#define sSrvC_ChnlMaxVolPerDay          1055
#define sSrvC_ChnlDir                   1056
#define sSrvC_ChnlInboxDelay            1057
#define sSrvC_ChnlAbsPrior              1058
#define sSrvC_ChnlRelPrior              1059
#define sSrvC_ProviderAdd               1101
#define sSrvC_ProviderDelete            1102
#define sSrvC_ProviderView              1103
#define sSrvC_ProviderSetup             1104
#define sSrvC_GetSettings               1104
#define sSrvC_UserAdd                   1201
#define sSrvC_UserDelete                1202
#define sSrvC_UserView                  1203
#define sSrvC_ChannelAdd                1301
#define sSrvC_ChannelDelete             1302
#define sSrvC_ChannelView               1303
#define sSrvC_DVBFormat                 1400
#define sSrvC_ListCtrl                  1401
#define sSrvC_DVBAliveSignal            1402
#define sSrvC_DVBLogFileName            1403
#define sSrvC_DVBLogDelay               1404
#define sSrvC_DVBAddRate                1405
#define sSrvC_DVBDeleteRate             1406
#define sSrvC_SetupTab                  2000
#define sSrvC_UserSendFile              2119
#define sSrvC_ApplaySettings            2120
#define sSrvC_ChnlStartStop             2121
#define sSrvC_ChnlRelPriorOn            2122
#define sSrvC_ChnlAbsPriorOn            2123
#define sSrvC_ChnlMaxVolPerDayOn        2124
#define sSrvC_ChnlRebroadcastDelay      2125
#define sSrvC_ChnlUseEncription         2126
#define sSrvC_ChnlUseCompression        2127
#define sSrvC_ChnlFEC                   2128
#define sSrvC_DVBPID                    2129
#define sSrvC_DVBPSITable               2130
#define sSrvC_UserSendUserTable         2142
#define sSrvC_DVBAliveInterval          2144
#define sSrvC_DVB_ECP                   2145
#define sSrvC_DVB_LVDS                  2146
#define sSrvC_DVB_ASI                   2147
#define sSrvC_DVBDayRate                2148
#define sSrvC_DVBDays                   2149
#define sSrvC_ChnlPID                   2151
#define sSrvC_AdrProviderChannels       2152
#define sSrvC_DVB_AbsPriPart            2154
#define sSrvC_ChannelSendFile           2155
#define sSrvC_AdrCACheck                2156
#define sSrvC_FirstDynamicIPAdress      2169
#define sSrvC_NumberOfDynIPAdress       2170
#define sSrvC_SizeOfOutputQueue         2171
#define IDC_TCPPort                     2173
#define IDC_SettingType                 2179

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        227
#define _APS_NEXT_COMMAND_VALUE         32795
#define _APS_NEXT_CONTROL_VALUE         2180
#define _APS_NEXT_SYMED_VALUE           218
#endif
#endif
