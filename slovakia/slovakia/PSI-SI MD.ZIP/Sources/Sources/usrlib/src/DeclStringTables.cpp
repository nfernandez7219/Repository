#include "tools2.hpp"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#include "screen.msg"

#include "errors.msg"


declStringTable( SCR ) ;
declStringTable( errors );
