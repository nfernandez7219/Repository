//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by F:\Dev\MFC\APPLIB\winnt\RC\E\ConnectDlg.rc
//
#define sFoxD_UserConnectionMSMQFoundLocations 11002
#define sFoxD_UserConnectionMSMQTestQueue 11003
#define sFoxD_UserConnectionMSMQWaitThread 11004
#define sFoxD_UserConnectionDlg         11005
#define sFoxD_ConnectionFailedDlg       11006
#define sFoxD_UserConnectionTCP         11007
#define sFoxD_UserConnectionSOCKET_Client 11008
#define sFoxD_UserConnection            11009
#define sFoxD_UserConnectionMedium      11010
#define sFoxD_ConnectionMediumSettings  11011
#define sFoxD_UserConnectionMSMQ        11012
#define sFoxD_UserConnectionSOCKET_Server 11013
#define sFoxC_MediumAllowed             11200
#define jFoxC_MSMQByMachine             11201
#define jFoxC_MSMQByPath                11202
#define jFoxC_MSMQByLabel               11203
#define jFoxC_MSMQBrowseMachine         11205
#define jFoxC_MSMQMachine               11206
#define jFoxC_MSMQPath                  11207
#define jFoxC_MSMQFindFormatName        11208
#define jFoxC_MSMQTestQueue             11208
#define jFoxC_MSMQLabel                 11209
#define jFoxC_MSMQLocateLabel           11210
#define jFoxC_MSMQFormatName            11211
#define sFoxC_MSMQFoundQueues           11212
#define jFoxC_MSMQMediumAllowed         11213
#define jFoxC_MSMQTestOutput            11215
#define jFoxC_MSMQTestOutputUpdate      11216
#define jFoxC_MSMQThreadFinished        11217
#define jFoxC_ConnErrorDesc             11218
#define sFoxC_TCPTest                   11219
#define sFoxC_UseIP                     11220
#define sFoxC_IP                        11221
#define sFoxC_Machine                   11222
#define sFoxC_Browse                    11223
#define sFoxC_TCPPort                   11224
#define sFoxC_ConnectGroupTab           11225
#define sFoxC_SaveConnection            11226
#define sFoxC_UndoConnection            11227
#define sFoxC_DefaultConnection         11228
#define sFoxC_ConnectionMedium          11229
#define sFoxC_ApplyConnection           11230

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        11014
#define _APS_NEXT_COMMAND_VALUE         11901
#define _APS_NEXT_CONTROL_VALUE         11233
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
