#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "cmdq_mgr.h"
#include "main.h"



void cmdq_mgr_init(void)
{
	int i, j;

	cmdq_mgr_queue_init(&freelistqueue);

	// init freelist
//	for (i = 0; i < FREELIST_MAX; i++)
	for (i = 0; i < MAXTEST*QP_MAX; i++)
	{
		cmdq_mgr_freelist_init(&freelistqueue);
	}

	for (j = 0; j < (QP_MAX); j++)
	{	
		cmdq_mgr_queue_init(&qpqueue[j]);
		cmdq_mgr_queue_init(&activequeue[j]);
	}
}

void cmdq_mgr_queue_init(struct node **cmdq_mgr_queue)
{
	*cmdq_mgr_queue = NULL;
}

void cmdq_mgr_freelist_init(struct node **freelist)
{
	struct node *newnode = (struct node*)malloc(sizeof(struct node));
	struct node *lastnode = (struct node*)malloc(sizeof(struct node));

	freelist_cnt++;
	newnode->data = 0xbeefbeef;
	newnode->key = freelist_cnt;

	if (*freelist == NULL)
	{
		newnode->next = newnode->prev = newnode;
		*freelist = newnode;
		return;
	}

	// if the list is not empty
	// find the last node
	lastnode = (*freelist)->prev;

	newnode->next = (*freelist);

	// make new node previous of start
	(*freelist)->prev = newnode;

	// make last previous of new node
	newnode->prev = lastnode;

	// make new node next of old last
	lastnode->next = newnode;

	return;
}

struct node* cmdq_mgr_node_get(void)
{
	struct node *newnode = (struct node*)malloc(sizeof(struct node));

	newnode = cmdq_mgr_delete_at_head(&freelistqueue);

	return newnode;
}

struct node* cmdq_mgr_delete_at_head(struct node **freelist)
{
	struct node *newnode = (struct node*)malloc(sizeof(struct node));
	struct node *lastnode = (struct node*)malloc(sizeof(struct node));

	if (*freelist == NULL)
	{
		newnode = *freelist;
		return newnode;
	}

	lastnode = (*freelist)->prev;
	newnode = *freelist;

	// check if only one node is available
	if ((*freelist) == lastnode)
	{
		newnode->next = newnode;
		newnode->prev = newnode;
		*freelist = NULL;
		return newnode;
	}

	*freelist = (*freelist)->next;
	(*freelist)->prev = lastnode;

	newnode->next = newnode;
	newnode->prev = newnode;

	return newnode;
}

int cmdq_mgr_tail_insert(struct node **newnode, int qp)
{
	cmdq_mgr_tail_insert2(newnode, &qpqueue[qp]);

	return 0;
}

struct node* cmdq_mgr_send_to_active(struct node **newnode, int qp)
{
	struct node *tempnode = (struct node*)malloc(sizeof(struct node));

	tempnode = *newnode;

	cmdq_mgr_node_delete(&qpqueue[qp], newnode);

	tempnode->next = tempnode;
	tempnode->prev = tempnode;
	cmdq_mgr_tail_insert2(&tempnode, &activequeue[qp]);

	return tempnode;
}

int cmdq_mgr_tail_insert2(struct node **newnode, 
                          struct node **queuestorage)
{
	struct node *lastnode = (struct node*)malloc(sizeof(struct node));

	if (*queuestorage == NULL)
	{
		*queuestorage = *newnode;
		return 0;
	}

	lastnode = (*queuestorage)->prev;
	(*newnode)->next = *queuestorage;
	(*queuestorage)->prev = *newnode;
	(*newnode)->prev = lastnode;
	lastnode->next = *newnode;
}

void cmdq_mgr_node_delete(struct node **cmdqnode, struct node **delnode)
{	
	if (*cmdqnode == NULL)
	{
		// nothing to be deleted
		while(1);
	}

	*delnode = *cmdqnode;

	while((*delnode)->next != *cmdqnode) 
	{
		*delnode = (*delnode)->next;
	}

	(*delnode)->next = (*cmdqnode)->next;
	(*cmdqnode)->next->prev = *delnode;
	*cmdqnode = (*delnode)->next;
}

int cmdq_mgr_node_return(struct node **returnqueue, int qp) 
						  
{	
	struct node *tempnode = (struct node*)malloc(sizeof(struct node));

	tempnode = *returnqueue;

	cmdq_mgr_node_delete2(&activequeue[qp], returnqueue);

	tempnode->next = tempnode;
	tempnode->prev = tempnode;
	cmdq_mgr_tail_insert2(&tempnode, &freelistqueue);

	return 0;
}

void cmdq_mgr_node_delete2(struct node **cmdqnode, struct node **delnode)
{
	struct node *tail = (struct node*)malloc(sizeof(struct node));

	if (*cmdqnode == NULL)
	{
		while(1);	// nothing to delete
	}

	if (*cmdqnode == (*cmdqnode)->next)
	{
		// only one node
		if (*cmdqnode == *delnode)
		{
			(*cmdqnode)->next = NULL;
			(*cmdqnode)->prev = NULL;
			return;
		}
		else
		{
			while(1);	// cannot find node to be deleted
		}
	}

	tail = (*cmdqnode)->prev;

	// traverse
	while(*cmdqnode != *delnode)
	{
		*cmdqnode = (*cmdqnode)->next;
	}

	*cmdqnode = (*cmdqnode)->next;
	(*cmdqnode)->prev = tail;	// tail to new head->prev
	tail->next = *cmdqnode;
}


