#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct node {
   int data;
   int key;
	
   struct node *next;
   struct node *prev;
};

#define QP_MAX			8
#define QUEUE_MAX		256
#define	FREELIST_MAX	(QUEUE_MAX * QP_MAX)

struct node *freelistqueue;
struct node *qpqueue[8];
struct node *activequeue[8];

int			freelist_cnt;


void cmdq_mgr_init(void);
struct node* cmdq_mgr_node_get(void);
int cmdq_mgr_tail_insert(struct node **newnode, 
					     int qp); 
struct node* cmdq_mgr_send_to_active(struct node** newnode,
	                                 int qp);
int cmdq_mgr_node_return(struct node **newnode, 
						  int qp); 


void cmdq_mgr_freelist_init(struct node **freelist);
void cmdq_mgr_queue_init(struct node **cmdq_mgr_queue);
struct node* cmdq_mgr_delete_at_head(struct node **freelist);
void cmdq_mgr_node_delete(struct node **cmdqnode, struct node **delnode);
int cmdq_mgr_tail_insert2(struct node **newnode, struct node **queuestorage);
void cmdq_mgr_node_delete2(struct node **cmdqnode, struct node **delnode);


