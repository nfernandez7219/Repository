#include "encdecdialog.h"
#include "ui_encdecdialog.h"
#include <QMessageBox>
#include <QDateTime>
#include <QMediaPlayer>
#include <QFile>

bool encdecns = false;

encdecDialog::encdecDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::encdecDialog)
{
    ui->setupUi(this);

    progressbar = new QProgressBar();
    ui->progressBar->setMinimum(0);
    ui->progressBar->setMaximum(100);
    ui->progressBar->hide();
    progressval = 0;

    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()),
            this, SLOT(updateprogress()));

    timer->start(1000);
}

encdecDialog::~encdecDialog()
{
    delete ui;
}

void encdecDialog::savenamespace(QString ns)
{
    encdecitemns = ns;
}

void encdecDialog::savexphy(QString xphy)
{
    encdecitemxphy = xphy;

    if (xphy == "XPHY1")
    {
        setcomboitem(0);
    }
    else
    {
        setcomboitem(1);
    }
}

void encdecDialog::setcomboitem(int idx)
{
    ui->comboBox->setCurrentIndex(idx);
}

void encdecDialog::saveData(CONFIG_DATA *ConfigData)
{
    this->ConfigData =  ConfigData;

    return;
}

void encdecDialog::enadiscombobox(bool val)
{
    ui->comboBox->setEnabled(val);
}

void encdecDialog::enadiscomboboxns(bool val)
{
    ui->comboBox_2->setEnabled(val);
}

void encdecDialog::enadispbutton2(bool val)
{
    ui->pushButton_2->setEnabled(val);
}

void encdecDialog::setcombotext(QString str)
{
    ui->comboBox->addItem(str);
}

void encdecDialog::setcombotextns(QString str)
{
    ui->comboBox_2->addItem(str);
}

void encdecDialog::setfocus(void)
{
    ui->lineEdit->setFocus();
}

void encdecDialog::disableradioall()
{
    ui->checkBox->setEnabled(false);
    ui->checkBox_2->setEnabled(false);
    ui->checkBox_3->setEnabled(false);
    ui->checkBox_4->setEnabled(false);
    ui->checkBox_5->setEnabled(false);
    ui->checkBox_6->setEnabled(false);
    ui->checkBox_7->setEnabled(false);
    ui->checkBox_8->setEnabled(false);
}

void encdecDialog::enableradioall()
{
    ui->checkBox->setEnabled(true);
    ui->checkBox_2->setEnabled(true);
    ui->checkBox_3->setEnabled(true);
    ui->checkBox_4->setEnabled(true);
    ui->checkBox_5->setEnabled(true);
    ui->checkBox_6->setEnabled(true);
    ui->checkBox_7->setEnabled(true);
    ui->checkBox_8->setEnabled(true);
}

void encdecDialog::enadisradio(int pos, bool val)
{
    switch(pos)
    {
        case 1: ui->checkBox->setEnabled(val);
        break;

        case 2: ui->checkBox_2->setEnabled(val);
        break;

        case 3: ui->checkBox_3->setEnabled(val);
        break;

        case 4: ui->checkBox_4->setEnabled(val);
        break;

        case 5: ui->checkBox_5->setEnabled(val);
        break;

        case 6: ui->checkBox_6->setEnabled(val);
        break;

        case 7: ui->checkBox_7->setEnabled(val);
        break;

        case 8: ui->checkBox_8->setEnabled(val);
        break;

        default:
        break;
    }

    return;
}

#include "flexxlib.h"
extern flexxon::flexxDriveList driveList;

void encdecDialog::on_pushButton_clicked()
{
    QString         FileReport = QString("../../reports/") + "report.csv";
    QFile           ReportFile(FileReport);
    QTextStream     Data(&ReportFile);
    static QMutex   wait;

    if (ui->comboBox != NULL)
    {
        encdecitemxphy = ui->comboBox->currentText();
    }

    if (encdecitemxphy == "XPHY1")
    {
        if (ConfigData->cfgoption[0].password == ui->lineEdit->text())
        {
            QMediaPlayer *music = new QMediaPlayer(this);
            music->setMedia(QUrl::fromLocalFile("../../resources/media/passed.mp3"));
            music->setVolume(50);
            music->play();

            ui->comboBox_2->setEnabled(true);
            ui->pushButton_2->setEnabled(true);
            enadisradio(1, true);   // checkbox default to namespace1

            // call api here for encrypt/decrypt enable
            flexxon::FlexxDecorator flexxdisk(driveList[0]);
            char temp_pass[] = "password";

            wait.lock();
            flexxdisk.encryption(temp_pass, strlen(temp_pass), 1);
            wait.unlock();


#if 0
            // call api for encrypt/decrypt enable
            // producer
            int datasize = 1024;
            for (int i = 0; i < datasize; i++)
            {
                mutex.lock();
                if (numusedbytes == BUFFERSIZE)
                    buffernotfull.wait(&mutex);
                mutex.unlock();

                buffer[i % BUFFERSIZE] = 8;

                mutex.lock();
                ++numusedbytes;
                buffernotempty.wakeAll();
                mutex.unlock();
            }

            // consumer
            for (int i = 0; i < DataSize; ++i) {
                mutex.lock();
                if (numUsedBytes == 0)
                    bufferNotEmpty.wait(&mutex);
                mutex.unlock();

                fprintf(stderr, "%c", buffer[i % BufferSize]);

                mutex.lock();
                --numUsedBytes;
                bufferNotFull.wakeAll();
                mutex.unlock();
            }
            fprintf(stderr, "\n");

            signals:
                void stringConsumed(const QString &text);
#endif

            QString logmsg, pw;
            logmsg = ui->comboBox->currentText();
            QString date = QDate::currentDate().toString("MM/dd/yyyy");
            QString time = QTime::currentTime().toString("hh:mm:ss");
//            logmsg = QString(logmsg).append("  "+date);
//            logmsg = QString(logmsg).append("  "+time);
            logmsg = QString(logmsg).append("--> "+date);
            logmsg = QString(logmsg).append("  "+time);
            pw = "Password Verified passed!";
            logmsg = QString(logmsg).append("  "+pw);
            emit eventsignal(logmsg);

            if (ReportFile.open(QIODevice::WriteOnly | QIODevice::Append))
            {
                Data << QString(REPORT_CONTENTS).arg(date).arg(time).arg(encdecitemxphy)
                                                .arg(ui->comboBox_2->currentText())
                                                .arg(pw);

                ReportFile.close();
            }
            else
            {
                logmsg = "Failed to create a report file!  ";
                logmsg = QString(logmsg).append("  "+time);
                logmsg = QString(logmsg).append("  "+date);
                emit eventsignal(logmsg);
            }

        }
        else
        {
            QMediaPlayer *music = new QMediaPlayer(this);
            music->setMedia(QUrl::fromLocalFile("../../resources/media/ErrorSound.wav"));
            music->setVolume(50);
            music->play();

            QString logmsg, pw;
            logmsg = ui->comboBox->currentText();
            QString date = QDate::currentDate().toString("MM/dd/yyyy");
            QString time = QTime::currentTime().toString("hh:mm:ss");
            logmsg = QString(logmsg).append("--> "+date);
            logmsg = QString(logmsg).append("  "+time);
            pw = "Password Verified failed!";
            logmsg = QString(logmsg).append("  "+pw);
            emit eventsignal(logmsg);

            if (ReportFile.open(QIODevice::WriteOnly | QIODevice::Append))
            {
                Data << QString(REPORT_CONTENTS).arg(date).arg(time).arg(encdecitemxphy)
                                                .arg(ui->comboBox_2->currentText())
                                                .arg(pw);

                ReportFile.close();
            }
            else
            {
                logmsg = "Failed to create a report file!  ";
                logmsg = QString(logmsg).append("  "+time);
                logmsg = QString(logmsg).append("  "+date);
                emit eventsignal(logmsg);
            }
        }
    }
    else if (encdecitemxphy == "XPHY2")
    {
        if (ConfigData->cfgoption[1].password == ui->lineEdit->text())
        {
            QMediaPlayer *music = new QMediaPlayer(this);
            music->setMedia(QUrl::fromLocalFile("../../resources/media/passed.mp3"));
            music->setVolume(50);
            music->play();

            ui->comboBox_2->setEnabled(true);
            ui->pushButton_2->setEnabled(true);
            enadisradio(1, true);   // checkbox default to namespace1

            QString logmsg, pw;
            logmsg = ui->comboBox->currentText();
            QString date = QDate::currentDate().toString("MM/dd/yyyy");
            QString time = QTime::currentTime().toString("hh:mm:ss");
            logmsg = QString(logmsg).append("--> "+date);
            logmsg = QString(logmsg).append("  "+time);
            pw = " Password Verified passed!";
            logmsg = QString(logmsg).append("  "+pw);
            emit eventsignal(logmsg);

            if (ReportFile.open(QIODevice::WriteOnly | QIODevice::Append))
            {
                Data << QString(REPORT_CONTENTS).arg(date).arg(time).arg(encdecitemxphy)
                                                .arg(ui->comboBox_2->currentText())
                                                .arg(pw);

                ReportFile.close();
            }
            else
            {
                logmsg = "Failed to create a report file!  ";
                logmsg = QString(logmsg).append("  "+time);
                logmsg = QString(logmsg).append("  "+date);
                emit eventsignal(logmsg);
            }
        }
        else
        {
            QMediaPlayer *music = new QMediaPlayer(this);
            music->setMedia(QUrl::fromLocalFile("../../resources/media/ErrorSound.wav"));
            music->setVolume(50);
            music->play();

            QString logmsg, pw;
            logmsg = ui->comboBox->currentText();
            QString date = QDate::currentDate().toString("MM/dd/yyyy");
            QString time = QTime::currentTime().toString("hh:mm:ss");
            logmsg = QString(logmsg).append("--> "+date);
            logmsg = QString(logmsg).append("  "+time);
            pw = " Password Verified failed!";
            logmsg = QString(logmsg).append("  "+pw);
            emit eventsignal(logmsg);

            if (ReportFile.open(QIODevice::WriteOnly | QIODevice::Append))
            {
                Data << QString(REPORT_CONTENTS).arg(date).arg(time).arg(encdecitemxphy)
                                                .arg(ui->comboBox_2->currentText())
                                                .arg(pw);

                ReportFile.close();
            }
            else
            {
                logmsg = "Failed to create a report file!  ";
                logmsg = QString(logmsg).append("  "+time);
                logmsg = QString(logmsg).append("  "+date);
                emit eventsignal(logmsg);
            }
        }
    }
    else
    {
        // for debug once it happens
        while(1);
    }

    ui->lineEdit->clear();
    ui->lineEdit->setFocus();
}

void encdecDialog::on_pushButton_2_clicked()
{
    QString     FileReport = QString("../../reports/") + "report.csv";
    QFile       ReportFile(FileReport);
    QTextStream Data(&ReportFile);
    bool        checkboxstate;
    QString     state, nsstr, xphystr;
    int         nsno, xphyno;
    bool        statebool;

    nsstr = ui->comboBox_2->currentText();  // get ns
    nsno = nsstr.right(nsstr.size()-9).toInt();    // get string number only

    xphystr = ui->comboBox->currentText();          // xphy
    xphyno = xphystr.right(xphystr.size()-4).toInt();

    checkboxstate = getcheckboxstate(nsno);

    if (checkboxstate == true)// ui->checkBox->checkState())
    {
        state = "enabled";
        statebool = true;
    }
    else
    {
        state = "disabled";
        statebool = false;
    }

    QMediaPlayer *music = new QMediaPlayer(this);
    music->setMedia(QUrl::fromLocalFile("../../resources/media/tarakatak.mp3"));
    music->setVolume(50);
    music->play();

    ConfigData->xphy = ui->comboBox->currentText();
    ConfigData->cfgoption[xphyno-1].nspace[nsno-1] = ui->comboBox_2->currentText();
    ConfigData->cfgoption[xphyno-1].enablefeature[nsno-1].encdec = statebool;

    QString reportDate = QDate::currentDate().toString("MM/dd/yyyy");
    QString Time = QTime::currentTime().toString("hh:mm:ss");
    QString LogMessage = ui->comboBox->currentText();   // xphy
    LogMessage = QString(LogMessage).append("--> "+reportDate);
    LogMessage = QString(LogMessage).append("  "+Time);
    LogMessage = QString(LogMessage).append("  "+nsstr);
    LogMessage = QString(LogMessage).append(" Encryption is");
    LogMessage = QString(LogMessage).append("  "+state);
    emit eventsignal(LogMessage);

    if (ReportFile.open(QIODevice::WriteOnly | QIODevice::Append))
    {
        Data << QString(REPORT_CONTENTS).arg(reportDate).arg(Time).arg(encdecitemxphy)
                                        .arg(nsstr)
                                        .arg("Encryptiong/Decryption is "+state);

        ReportFile.close();
    }
    else
    {
        QString logmsg;
        logmsg = "Failed to create a report file!  ";
        logmsg = QString(logmsg).append("  "+Time);
        logmsg = QString(logmsg).append("  "+reportDate);
        emit eventsignal(logmsg);
    }

    ui->comboBox_2->setEnabled(false);
    ui->pushButton_2->setEnabled(false);
    enadisradio(1, true);   // checkbox default to namespace1

}

void encdecDialog::on_comboBox_2_activated(int index)
{
    disableradioall();
    enadisradio(index+1, true);
}

bool encdecDialog::getcheckboxstate(int checkboxsel)
{
    bool state;

    switch(checkboxsel)
    {
        case 1: state = ui->checkBox->checkState();
        break;

        case 2: state = ui->checkBox_2->checkState();
        break;

        case 3: state = ui->checkBox_3->checkState();
        break;

        case 4: state = ui->checkBox_4->checkState();
        break;

        case 5: state = ui->checkBox_5->checkState();
        break;

        case 6: state = ui->checkBox_6->checkState();
        break;

        case 7: state = ui->checkBox_7->checkState();
        break;

        case 8: state = ui->checkBox_8->checkState();
        break;

        default:
        break;
    }

    return state;
}


void encdecDialog::on_comboBox_2_activated(const QString &arg1)
{
    QString FileReport = QString("../../reports/") + "report.csv";
    QFile ReportFile(FileReport);
    QTextStream Data(&ReportFile);
//    bool FileExist = false;
    QString state, nsstr, xphystr;
    QString logmsg;
    int nsno;
    int xphyno;

    nsstr = ui->comboBox_2->currentText();          // get ns
    nsno = arg1.right(arg1.size()-9).toInt();     // get string number only

    xphystr = ui->comboBox->currentText();          // xphy
    xphyno = xphystr.right(xphystr.size()-4).toInt();

    if (ConfigData->cfgoption[xphyno-1].enablefeature[nsno-1].encdec == false)
    {
        enadisradio(nsno, false);

        QMediaPlayer *music = new QMediaPlayer(this);
        music->setMedia(QUrl::fromLocalFile("../../resources/media/ErrorSound.wav"));
        music->setVolume(50);
        music->play();

        ui->pushButton_2->setEnabled(false);
        logmsg = ui->comboBox->currentText();
        QString date = QDate::currentDate().toString("MM/dd/yyyy");
        QString time = QTime::currentTime().toString("hh:mm:ss");
        logmsg = QString(logmsg).append("--> "+date);
        logmsg = QString(logmsg).append("  "+time);
        logmsg = QString(logmsg).append("  Encryption/Decryption is not available to this");
        logmsg = QString(logmsg).append("  "+nsstr);
        emit eventsignal(logmsg);

        if (ReportFile.open(QIODevice::WriteOnly | QIODevice::Append))
        {
            Data << QString(REPORT_CONTENTS).arg(date).arg(time).arg(xphystr)
                                            .arg(nsstr)
                                            .arg("Encryption/Decryption is not available to this "+nsstr);

            ReportFile.close();
        }
        else
        {
            logmsg = "Failed to create a report file!  ";
            logmsg = QString(logmsg).append("  "+time);
            logmsg = QString(logmsg).append("  "+date);
            emit eventsignal(logmsg);
        }

        return;
    }

    ui->pushButton_2->setEnabled(true);
}

void encdecDialog::updateprogress()
{
/*    ui->progressBar->show();

    progressval++;
    ui->progressBar->setValue(progressval);*/
}


