#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <QTextStream>
#include <QtCharts/QChartView>
#include <QtCharts/QBarSet>
#include <QtCharts/QBarCategoryAxis>
#include <QtCharts/QValueAxis>
#include <QDateTime>
#include <QMediaPlayer>
#include <QFileDialog>

#include "passworddialog.h"
#include "protzonedialog.h"
#include "policydialog.h"
#include "lockunlockdialog.h"
#include "encdecdialog.h"
#include "secureerasedialog.h"
#include "signupdatedialog.h"



MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    QString reportDate = QDate::currentDate().toString("MM/dd/yyyy");
    QString FileReport = QString("../../reports/") + "report.csv";
    QFile ReportFile(FileReport);
    QTextStream Data(&ReportFile);
    bool FileExist = false;

    if (ReportFile.exists())
    {
        FileExist = true;
    }

    if (ReportFile.open(QIODevice::WriteOnly | QIODevice::Append))
    {
        if (!FileExist)
        {
            Data << REPORT_HEADER;
        }

        ReportFile.close();
    }

    configDialog = new genconfigDialog(this);

    connect(configDialog,
            &genconfigDialog::eventsignal,
            this,
            &MainWindow::log_event);

#if BACKEND_ENABLE
    initializebackend();
#endif
    ui->progressBar->hide();

/*
    progressbar = new QProgressBar();
//    progressbar->setMinimum(0);
//    progressbar->setMaximum(100);
    ui->progressBar->setMinimum(0);
    ui->progressBar->setMaximum(100);
    ui->progressBar->hide();
    progressval = 0;

    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()),
            this, SLOT(updateprogress()));

    timer->start(1000);
*/

    // get initial information from the drive
    // these will be use for verification and display
    // password for xphy1, xpy2
    // get lock, policy, enc/dec, protect file, health graph

    // use genconfigdialog for all the information acquired from the drive and use it all through out.
    // maintain this copy so that after reboot, this copy will be regenerated

    ui->treeWidget->setContextMenuPolicy(Qt::CustomContextMenu);
    ui->treeWidget->topLevelItem(0)->setData(0,Qt::UserRole,"toplevel");

    for (int xphy=0; xphy < DEVICE_COUNT; xphy++)
    {
        for (int lock=0; lock < NAMESPACE_COUNT; lock++)
        {
            configDialog->configdata->cfgoption[xphy].featurelock[lock] = false;
        }
    }

    connect(ui->treeWidget,
            &QTreeWidget::customContextMenuRequested,
            this,
            &MainWindow::right_click_menu);

    connect(ui->treeWidget,
            &QTreeWidget::itemPressed,
            this,
            &MainWindow::item_pressed);

    connect(ui->treeWidget,
            &QTreeWidget::itemClicked,
            this,
            &MainWindow::item_clicked);

    connect(ui->pushButton,
            &QPushButton::clicked,
            this,
            &MainWindow::execute_lockunlock);

    create_actions();
    create_chart();
    create_tray_icon();
    set_hardcoded_data();
    set_tree_widget();
    set_tree_directory();
    hide_displays();

    device_health();

    return;
}

MainWindow::~MainWindow()
{
    //calculationthread->quit();
    //calculationthread->wait();
    //delete calculationWorker;

//    delete timer;
//    delete progressbar;

    delete DeviceDataHash;
    delete BarChart;
    delete ui;
}

void MainWindow::closeEvent(QCloseEvent *event)
{
    Q_UNUSED(event)
    return;
}

void MainWindow::create_actions()
{
    //Namespace Menu Options
    NamespaceMenu = new QMenu(this);

/*    Password = new QAction(QIcon(":/icons/icons/changepassword.png"),
                           tr("Change Password"), this);*/
    Protect = new QAction(QIcon(":/icons/icons/protectzone.png"),
                          tr("Protect Zone"), this);
    Policy = new QAction(QIcon(":/icons/icons/changepolicy.png"),
                         tr("Change Policy"), this);
    EncDec = new QAction(QIcon(":/icons/icons/encryption.png"),
                         tr("Enc/Dec"), this);
    SecErase = new QAction(QIcon(":/icons/icons/secureerase.jpg"),
                           tr("Secure Erase"), this);
    SignUpdate = new QAction(QIcon(":/icons/icons/signatureupdate.png"),
                             tr("Signature Update"), this);

//    Password->setStatusTip("Change Password...");
    Protect->setStatusTip("Protect/Lock the selected Namespace...");
    Policy->setStatusTip("Change Policy the selected Namespace...");
    EncDec->setStatusTip("Enable/Disable Enc/Dec for this Namespace");
    SecErase->setStatusTip("Secure Erase the selected Namespace...");
    SignUpdate->setStatusTip("A Signature object will be transferred to the selected Namespace...");

/*    connect(Password,
            &QAction::triggered,
            this,
            &MainWindow::changepassword);*/
    connect(Protect,
            &QAction::triggered,
            this,
            &MainWindow::protectzone);
    connect(Policy,
            &QAction::triggered,
            this,
            &MainWindow::changepolicy);
    connect(EncDec,
            &QAction::triggered,
            this,
            &MainWindow::encryptdecryptenable);
    connect(SecErase,
            &QAction::triggered,
            this,
            &MainWindow::secureerase);
    connect(SignUpdate,
            &QAction::triggered,
            this,
            &MainWindow::signatureupdate);

//    NamespaceMenu->addAction(Password);
    NamespaceMenu->addAction(Protect);
    NamespaceMenu->addAction(Policy);
    NamespaceMenu->addAction(EncDec);
    NamespaceMenu->addAction(SecErase);
    NamespaceMenu->addAction(SignUpdate);

    //Device Menu Options
    DeviceMenu = new QMenu(this);

/*    Create = new QAction(tr("Create Namespace"), this);
    Delete = new QAction(tr("Delete Namespace"), this);
    Attach = new QAction(tr("Attach Namespace"), this);*/
    Create = new QAction(QIcon(":/icons/icons/drive.png"),
                         tr("Create Namespace"), this);
    Delete = new QAction(QIcon(":/icons/icons/drive.png"),
                         tr("Delete Namespace"), this);
    Attach = new QAction(QIcon(":/icons/icons/drive.png"),
                         tr("Attach Namespace"), this);
    Password = new QAction(QIcon(":/icons/icons/changepassword.png"),
                           tr("Change Password"), this);

    Create->setStatusTip("Create Namespace...");
    Delete->setStatusTip("Delete Namespace...");
    Attach->setStatusTip("Attach Namespace...");
    Password->setStatusTip("Change Password...");

    connect(Create,
            &QAction::triggered,
            this,
            &MainWindow::create_namespace);
    connect(Delete,
            &QAction::triggered,
            this,
            &MainWindow::delete_namespace);
    connect(Attach,
            &QAction::triggered,
            this,
            &MainWindow::attach_namespace);
    connect(Password,
            &QAction::triggered,
            this,
            &MainWindow::changepassword);

    DeviceMenu->addAction(Create);
    DeviceMenu->addAction(Delete);
    DeviceMenu->addAction(Attach);
    DeviceMenu->addAction(Password);

    //    ui->statusbar->setFont()
//    ui->statusbar->setStyleSheet("color: blue");
    ui->statusbar->setStyleSheet("color: white");
    ui->statusbar->showMessage("Right-Click to XPHY or Namespace objects to access the features!");

    return;
}

void MainWindow::create_chart()
{
    BarChart = new QChart();
    BarChart->setTitle("XPHY NVME Device Health");
    BarChart->setAnimationOptions(QChart::SeriesAnimations);
    BarChart->legend()->hide();
//    BarChart->legend()->setAlignment(Qt::AlignBottom);

    QStringList categories;
//    categories << "availspare" << "avail thresh" << "cntl bus time" << "power cycle" << "unsafe shutdown" << "numberlogerr";
    categories << "avail thold" << "cntl busy" << "pwr cycle" << "unsafe sd" << "info error";// << "temp" ;
//    categories << "avail thold" << "cntl busy" << "pwr cycle" << "unsafe sd" << "info error";
    QBarCategoryAxis *axisX = new QBarCategoryAxis();   //
    axisX->append(categories);
    BarChart->addAxis(axisX, Qt::AlignBottom);

    QValueAxis *axisY = new QValueAxis();
    axisY->setRange(0, 100);
    BarChart->addAxis(axisY, Qt::AlignLeft);

    QChartView *BarChartView = new QChartView(BarChart);
    BarChartView->setRenderHint(QPainter::Antialiasing);

    ui->gridLayout_3->addWidget(BarChartView, 0, 0);

    return;
}

void MainWindow::create_tray_icon()
{
    TrayMenu = new QMenu(this);
    Open = new QAction(tr("Open"), this);
    Exit = new QAction(tr("Exit"), this);
    QWidget *Parent = (QWidget*)this->parent();

    connect(Open,
            &QAction::triggered,
            Parent,
            &QWidget::show);
    connect(Exit,
            &QAction::triggered,
            qApp,
            &QCoreApplication::quit);

    TrayMenu->addAction(Open);
    TrayMenu->addAction(Exit);

    TrayIcon = new QSystemTrayIcon(QIcon(":/icons/icons/flexxon.png"), this);
    TrayIcon->setContextMenu(TrayMenu);
    TrayIcon->show();

    return;
}

void MainWindow::set_hardcoded_data()
{

    DeviceDataHash = new QHash<QString, DEVICE_DATA>;
    QString Key;
    QString nspace;
    DEVICE_DATA DevData;

//    for (int i = 0; i < DEVICE_COUNT; i++)
        for (int i = 0; i < 1; i++)
    {
        Key = QString(XPHY_NAME).append(QString::number(i+1));
        DevData.NsCount = NAMESPACE_COUNT;

//        for (int j = 0; j < NAMESPACE_COUNT; j++)
            for (int j = 0; j < 1; j++)
        {
            nspace = NAMESPACE_NAME;
            DevData.NS[j].NsName = QString(nspace).append(QString::number(j+1));
            DevData.NS[j].Data1 = QString(DevData.NS[j].NsName)\
                                      .append("_data1");
            DevData.NS[j].Data2 = QString(DevData.NS[j].NsName)\
                                      .append("_data2");
            DevData.NS[j].Data3 = QString(DevData.NS[j].NsName)\
                                      .append("_data3");
        }
        DeviceDataHash->insert(Key, DevData);
    }

    return;
}

/*
struct xphy_device {
    char subnqn[256];
};
*/
void MainWindow::set_tree_widget()
{
    QTreeWidgetItem *Children;
    QTreeWidgetItem *Children2;
    DEVICE_DATA DeviceData;
    QStringList Keys = DeviceDataHash->keys();
    Keys.sort();
/*
    // creat xphy vector
    std::vector<struct xphy_device> xphy_list;

    for (disk = driveList.begin(); disk < driveList.end(); disk++)
    {
        // send identify controller to disk
        // if xphy vector.size is zero, create new parent,add this to the xphy_list
        // else get correct parent from xphy vector

        // at this point there should be a parent pointer


        // send identify namespace to disk
        // create new child for this namespace
        // add this child to the parent


    }
*/
#if 0
//    DeviceData = DeviceDataHash->value(Name);
    DeviceData = DeviceDataHash->value("XPHY");
    Children = new QTreeWidgetItem(ui->treeWidget->topLevelItem(0));
    Children->setText(0,"XPHY1");
    Children->setIcon(0,QIcon(":/icons/icons/ssd.png"));
    Children->setData(0,Qt::UserRole,"devicename");

    Children2 = new QTreeWidgetItem(Children);
//    Children2->setText(0,DeviceData.NS[j].NsName);
    Children2->setText(0,DeviceData.NS[0].NsName);
    Children2->setIcon(0,QIcon(":/icons/icons/drive.png"));
    Children2->setData(0,Qt::UserRole,"namespace");
#endif

    foreach (QString Name, Keys)
    {
        DeviceData = DeviceDataHash->value(Name);
        Children = new QTreeWidgetItem(ui->treeWidget->topLevelItem(0));
        Children->setText(0,Name);
        Children->setIcon(0,QIcon(":/icons/icons/ssd.png"));
        Children->setData(0,Qt::UserRole,"devicename");

//        for (int j = 0; j < DeviceData.NsCount; j++)
            for (int j = 0; j < 1; j++)
        {
            Children2 = new QTreeWidgetItem(Children);
            Children2->setText(0,DeviceData.NS[j].NsName);
            Children2->setIcon(0,QIcon(":/icons/icons/drive.png"));
            Children2->setData(0,Qt::UserRole,"namespace");
        }
    }

    return;
}

void MainWindow::set_tree_directory()
{
    SystemModel = new QFileSystemModel(this);
    ui->treeView->setModel(SystemModel);

    connect(ui->treeView,
            &QTreeView::clicked,
            this,
            &MainWindow::lock_unlock);
/*
    connect(ui->treeView,
            &QTreeView::doubleClicked,
            this,
            &MainWindow::lock_unlock_dclick);
*/
    return;
}

void MainWindow::hide_displays()
{
//    ui->wgtXPHYInfo->hide();
//    ui->wgtHealthInfo->hide();
    ui->wgtLockUnlock->hide();

    return;
}

void MainWindow::device_clicked()
{
    // check policy here

    if (TrayIcon->isVisible())
    {
        configDialog->configdata->cfgoption[0].policies[0].policy1;
//        ConfigData->cfgoption[xphyno-1].policies[nsno-1].policy1

     /*   flexxon::flexxDriveList driveList;

        static flexxon::flexxDriveList::iterator disk;
        struct identify_controller_struct id_control;
        struct identify_namespace_struct id_namespace;
        std::vector<struct log_err_info_struct> err_info;
        struct log_smart_info_struct smart_info_global;

        scan_devices(driveList);

        // free space
//        struct identify_namespace_struct id_namespace;

        int lbasizeidx = id_namespace.flbas;    // formatted lba size
        int lbasize = 1 << id_namespace.lbaf[lbasizeidx].lbads;

        double diskcapinbytes = id_namespace.ncap/lbasize;
        uint64_t sizegb = diskcapinbytes/(1024*4);

        double totcapacity = (512 * 1024) * 1024;
        uint64_t freespace = (sizegb * 1024) * 1024;
        uint64_t remaining = totcapacity - freespace;

        QString sizegigabyte = QString::number(sizegb);
        ui->label_54->setStyleSheet("color: yellow");
        ui->label_54->setText(sizegigabyte+" GB");

        // check temperature
        // check unsafe shutdown
        // check media and data integrity errors
        // check number of error informaton log entries
        // check critical warning
*/
        TrayIcon->showMessage(windowTitle(),
                              tr("The nats program will keep running in the "
                                 "system tray. To terminate the program, "
                                 "choose Exit in the context menu "
                                 "of the system tray entry."));

    }
    else
    {
        close();
    }



    return;
}

void MainWindow::namespace_clicked()
{
    QString Path = "C:";
    SystemModel->setRootPath(Path);
    ui->treeView->setRootIndex(SystemModel->index(Path));
    ui->wgtLockUnlock->show();
    ui->pushButton->setEnabled(false);

    return;
}

void MainWindow::device_health()
{
    QString xphystr;
    int xphyno;

    CurrentXphyName = "XPHY1";

    if (CurrentXphyName == "XPHY1")
    {
        xphystr = CurrentXphyName;
        xphyno = xphystr.right(xphystr.size()-4).toInt();

        QBarSeries *BarSeries = new QBarSeries();
        QBarSet *smartdata = new QBarSet("");
        BarChart->removeAllSeries();

        //uint32_t availspare = xphyhealth[0].info1;
        //availspare = (availspare & INFO1_AVAIL_SPARE_MAKE) >> 24;

//        uint8_t temp = xphyhealth[0].info1;
//        temp = ((temp & INFO1_COMPOSITE_TEMP_MASK) >> 8) - 273.15;

        //        float temp = tempa - 273.15; // kelvin to celcius
//        QString compositetemp = QString::number(temp);

        uint64_t availthresh = xphyhealth[0].avail_spare_threshold;

        uint64_t cntlbusytime = xphyhealth[0].controller_busy_time.lo;

        uint64_t powercycle = xphyhealth[0].power_cycles.lo;

        uint64_t unsafeshutdown = xphyhealth[0].unsafe_shutdowns.lo;

        uint8_t numberlogerr = xphyhealth[0].number_of_error_info_log_entries.lo;


//        *smartdata << availthresh << cntlbusytime << powercycle << unsafeshutdown << numberlogerr;// << temp ;
        *smartdata << 23 << 5 << 9 << 1 << 35;

        BarSeries->append(smartdata);
        BarChart->addSeries(BarSeries);
    }
    else if (CurrentXphyName == "XPHY2")
    {
        // xphy2
    }
    else
    {
        QMediaPlayer *music = new QMediaPlayer(this);
        music->setMedia(QUrl::fromLocalFile("../../resources/media/tarakatak.mp3"));
        music->setVolume(50);
        music->play();

        log_event("unkown device id");
    }


    if (TrayIcon->isVisible())
    {
        // transfer to smart health info
        // when one of the parameters is critical, show this critical information
        TrayIcon->showMessage(windowTitle(),
                              tr("The nats program will keep running in the "
                                 "system tray. To terminate the program, "
                                 "choose Exit in the context menu "
                                 "of the system tray entry."));

//        hide();
    }
    else
    {
        close();
    }

    return;
}

void MainWindow::right_click_menu(const QPoint &pos)
{
    QModelIndex Index = ui->treeWidget->indexAt(pos);

    if (Index.isValid())
    {
        if (ItemType == "namespace")
        {
            NamespaceMenu->exec(ui->treeWidget->mapToGlobal(pos));
        }
        else if (ItemType == "devicename")
        {
            DeviceMenu->exec(ui->treeWidget->mapToGlobal(pos));
        }
    }

    return;
}

void MainWindow::item_pressed(QTreeWidgetItem *item, int Col)
{    
    CurrentItem = item;
    ItemName = CurrentItem->text(Col);
    ItemType = CurrentItem->data(0,Qt::UserRole).toString();

    if (ItemType == "namespace")
    {
        CurrentXphyName = CurrentItem->parent()->text(Col);
    }

    return;
}

void MainWindow::item_clicked(QTreeWidgetItem *item, int Col)
{
    Q_UNUSED(item)
    Q_UNUSED(Col)

    //initially hide all displays
    hide_displays();

    if (ItemType == "devicename")
    {
        ui->tabWidget->setCurrentIndex(0);
        ui->wgtXPHYInfo->show();
        device_clicked();
    }
    else if (ItemType == "namespace")
    {
        ui->tabWidget->setCurrentIndex(2);
        ui->wgtLockUnlock->show();
        ui->wgtHealthInfo->show();
        namespace_clicked();
        //device_health();
    }

    return;
}

void MainWindow::log_event(QString str)
{
    ui->textBrowser->append(str);

    return;
}

QString MainWindow::get_log(void)
{
    QString text = ui->textBrowser->toPlainText();

    return text;
}

void MainWindow::generatereport()
{
    QString reportDate = QDate::currentDate().toString("MM/dd/yyyy");
//    QTreeWidgetItem *ChildItem;
    //    QString FileReport = QString("../../reports/") + reportDate + "_Report.csv";
    QString FileReport = QString("../../reports/") + "report.csv";
    QFile ReportFile(FileReport);
    QTextStream Data(&ReportFile);
//    QString Date = QDate::currentDate().toString("MM/dd/yyyy");
//    QString Time = QTime::currentTime().toString("hh:mm:ss");
//    DEVICE_DATA DevData;
//    NAMESPACE_DATA NsData;
//    QString DeviceName, logmsg;
    QString logmsg;
    bool FileExist = false;
//    int NsIndex = 0;

/*    QString loginfo = get_log();

    if (ReportFile.exists())
    {
        FileExist = true;
    }
*/
    if (ReportFile.open(QIODevice::WriteOnly | QIODevice::Append))
    {
        if (!FileExist)
        {
            Data << REPORT_HEADER;
        }

        QString date = QDate::currentDate().toString("MM/dd/yyyy");
        QString time = QTime::currentTime().toString("hh:mm:ss");
        logmsg = "Generate report has been requested!  ";
        logmsg = QString(logmsg).append("  "+time);
        logmsg = QString(logmsg).append("  "+date);
        log_event(logmsg);

        Data << QString(REPORT_CONTENTS).arg(date).arg(time).arg("XPHY")
                                        .arg("Namespace")
                                        .arg("Generate report has been requested!");

        ReportFile.close();
    }
    else
    {
        QString date = QDate::currentDate().toString("MM/dd/yyyy");
        QString time = QTime::currentTime().toString("hh:mm:ss");
        logmsg = "Failed to create a report file!  ";
        logmsg = QString(logmsg).append("  "+time);
        logmsg = QString(logmsg).append("  "+date);
        log_event(logmsg);
    }

    return;
}

void MainWindow::changepassword()
{
    passwordDialog Password(this);

//    Password.savenamespace(ItemName);
    Password.addcombotext("XPHY1");
//    Password.addcombotext("XPHY2");
    Password.savexphy(ItemName);
    Password.saveData(configDialog->returnData());
    Password.enadiscombobox(false);
    Password.setfocus();

    connect(&Password,
            &passwordDialog::eventsignal,
            this,
            &MainWindow::log_event);

    Password.exec();

    return;
}

void MainWindow::protectzone()
{
    protzoneDialog protect(this);

    protect.setcombotext("XPHY1");
//    protect.setcombotext("XPHY2");
    protect.savenamespace(ItemName);
    protect.savephxy(CurrentXphyName);
    protect.savedata(configDialog->returnData());
    protect.enadiscombobox(false);
    protect.enadiscomboboxns(false);
    protect.enadispbutton(true);
    protect.enadispbutton2(false);
    protect.enadispbutton3(false);
    protect.setcombotextns("namespace1");
/*    protect.setcombotextns("namespace2");
    protect.setcombotextns("namespace3");
    protect.setcombotextns("namespace4");
    protect.setcombotextns("namespace5");
    protect.setcombotextns("namespace6");
    protect.setcombotextns("namespace7");
    protect.setcombotextns("namespace8");*/
    protect.setfocus();

    connect(&protect,
            &protzoneDialog::eventsignal,
            this,
            &MainWindow::log_event);

    protect.exec();

    return;
}

void MainWindow::changepolicy()
{
    policyDialog policy(this);

    policy.setcombotext("XPHY1");
//    policy.setcombotext("XPHY2");
    policy.savenamespace(ItemName);
    policy.savephxy(CurrentXphyName);
    policy.savedata(configDialog->returnData());
    policy.enadiscombobox(true);
    policy.enadiscomboboxns(false);
    policy.enadispbutton(true);
    policy.enadispbuttonns(false);
    policy.enadischeckbox(false);
    policy.setcombotextns("namespace1");
/*    policy.setcombotextns("namespace2");
    policy.setcombotextns("namespace3");
    policy.setcombotextns("namespace4");
    policy.setcombotextns("namespace5");
    policy.setcombotextns("namespace6");
    policy.setcombotextns("namespace7");
    policy.setcombotextns("namespace8");*/
    policy.setfocus();

    connect(&policy,
            &policyDialog::eventsignal,
            this,
            &MainWindow::log_event);

    policy.exec();

    return;
}

void MainWindow::lockfile()
{
/*    lockunlockDialog Lock(this);

    Lock.savenamespace(ItemName);
    Lock.savexphy(CurrItemName);
    Lock.saveData(configDialog->returnData());
    Lock.enadiscombobox(true);
    Lock.setcombotext("XPHY1");
    Lock.setcombotext("XPHY2");
    Lock.enadiscomboboxns(false);
    Lock.enadispbutton2(false);
    Lock.setcombotextns("namespace1");
    Lock.setcombotextns("namespace2");
    Lock.setcombotextns("namespace3");
    Lock.setcombotextns("namespace4");
    Lock.setcombotextns("namespace5");
    Lock.setcombotextns("namespace6");
    Lock.setcombotextns("namespace7");
    Lock.setcombotextns("namespace8");
    Lock.setfocus();

    connect(&Lock,
            &lockunlockDialog::eventsignal,
            this,
            &MainWindow::log_event);

    Lock.exec();
*/
    return;
}

void MainWindow::encryptdecryptenable()
{
    encdecDialog encdec(this);

    encdec.setcombotext("XPHY1");
//    encdec.setcombotext("XPHY2");
    encdec.savenamespace(ItemName);
    encdec.savexphy(CurrentXphyName);
    encdec.saveData(configDialog->returnData());
    encdec.enadiscombobox(true);
    encdec.enadiscomboboxns(false);
    encdec.setcombotextns("namespace1");
/*    encdec.setcombotextns("namespace2");
    encdec.setcombotextns("namespace3");
    encdec.setcombotextns("namespace4");
    encdec.setcombotextns("namespace5");
    encdec.setcombotextns("namespace6");
    encdec.setcombotextns("namespace7");
    encdec.setcombotextns("namespace8");
*/
    encdec.enadispbutton2(false);
    encdec.disableradioall();
    encdec.setfocus();

    connect(&encdec,
            &encdecDialog::eventsignal,
            this,
            &MainWindow::log_event);

    encdec.exec();

    return;
}

void MainWindow::secureerase()
{
    secureeraseDialog secerase(this);

    secerase.setcombotext("XPHY1");
//    secerase.setcombotext("XPHY2");
    secerase.savenamespace(ItemName);
    secerase.savephxy(CurrentXphyName);
    secerase.saveData(configDialog->returnData());
    secerase.enadiscombobox(true);
    secerase.enadiscomboboxns(false);
    secerase.setcombotextns("namespace1");
/*    secerase.setcombotextns("namespace2");
    secerase.setcombotextns("namespace3");
    secerase.setcombotextns("namespace4");
    secerase.setcombotextns("namespace5");
    secerase.setcombotextns("namespace6");
    secerase.setcombotextns("namespace7");
    secerase.setcombotextns("namespace8");
*/
    secerase.enadispbutton2(false);
    secerase.setfocus();

    connect(&secerase,
            &secureeraseDialog::eventsignal,
            this,
            &MainWindow::log_event);

    secerase.exec();

    return;
}

void MainWindow::signatureupdate()
{

    QString filename = QFileDialog::getOpenFileName(this, "Open a File", QDir::homePath());
/*    QMessageBox::information(this, "..",filename);
    QString text;
    QMessageBox box;
    box.setText(filename);
*/

    QString logmsg, message;
    QString date = QDate::currentDate().toString("MM/dd/yyyy");
    QString time = QTime::currentTime().toString("hh:mm:ss");
    logmsg = "XPHY1";
    logmsg = QString(logmsg).append("--> "+date);
    logmsg = QString(logmsg).append("  "+time);
    logmsg = QString(logmsg).append(" Namespace1 ");
    logmsg = QString(logmsg).append(filename + " Sent this signature update file to xphy device");
    log_event(logmsg);


#if 0
    signupdateDialog sign(this);

    sign.setcombotext("XPHY1");
//    sign.setcombotext("XPHY2");
    sign.savenamespace(ItemName);
    sign.savexphy(CurrentXphyName);
    sign.saveData(configDialog->returnData());
    sign.enadiscombobox(true);
    sign.enadiscomboboxns(false);
    sign.setcombotextns("namespace1");
/*
    sign.setcombotextns("namespace2");
    sign.setcombotextns("namespace3");
    sign.setcombotextns("namespace4");
    sign.setcombotextns("namespace5");
    sign.setcombotextns("namespace6");
    sign.setcombotextns("namespace7");
    sign.setcombotextns("namespace8");
*/
    sign.enadispbutton2(false);
    sign.setfocus();

    connect(&sign,
            &signupdateDialog::eventsignal,
            this,
            &MainWindow::log_event);

    sign.exec();
#endif

    return;
}

void MainWindow::genconfiguration()
{
    // during initial launch policy must be none
    // second boot, must apply previous policy settings

    configDialog->setcombotext("XPHY1");
    configDialog->setcombotext("XPHY2");
    configDialog->setgroupboxns(false);
    configDialog->setgroupboxpol(false);
    configDialog->setfocus();
    configDialog->setcombotextns("namespace1");
    configDialog->setcombotextns("namespace2");
    configDialog->setcombotextns("namespace3");
    configDialog->setcombotextns("namespace4");
    configDialog->setcombotextns("namespace5");
    configDialog->setcombotextns("namespace6");
    configDialog->setcombotextns("namespace7");
    configDialog->setcombotextns("namespace8");
    configDialog->setpushbuttonupdcfg(false);
    configDialog->setcombostate(false);

    configDialog->exec();

    return;
}

void MainWindow::updatefirmware()
{
    return;
}

void MainWindow::about()
{
    return;
}

void MainWindow::create_namespace()
{
    QMessageBox::information(this,
                             "Report",
                             "create");

    return;
}

void MainWindow::delete_namespace()
{
    QMessageBox::information(this,
                             "Report",
                             "delete");

    return;
}

void MainWindow::attach_namespace()
{
    QMessageBox::information(this,
                             "Report",
                             "attach");

    return;
}

void MainWindow::lock_unlock(const QModelIndex &index)
{
    ui->pushButton->setEnabled(true);
    SelectedFile = SystemModel->filePath(index);

    return;
}

void MainWindow::lock_unlock_dclick(const QModelIndex &index)
{
    lock_unlock(index);

    if (!QDir(SelectedFile).exists())
    {
        execute_lockunlock();
    }

    return;
}

void MainWindow::execute_lockunlock()
{
    QString Message = QString("Lock / Unlock this file or folder?\n\n").append(SelectedFile);
//    int Ret = QMessageBox::question(this, tr("Lock / Unlock"), Message);

    int xphyno, nsno;

    xphyno = CurrentXphyName.right(CurrentXphyName.size()-4).toInt();
    nsno = ItemName.right(ItemName.size()-9).toInt();

    if (configDialog->configdata->cfgoption[xphyno-1].featurelock[nsno-1] == false)
    {
        lockunlockDialog Lock(this);

        //do lock/unlock here
        QMediaPlayer *music = new QMediaPlayer(this);
        music->setMedia(QUrl::fromLocalFile("../../resources/media/tarakatak.mp3"));
        music->setVolume(50);
        music->play();

        Lock.setcombotext("XPHY1");
//        Lock.setcombotext("XPHY2");
        Lock.saveData(configDialog->returnData());
        Lock.savenamespace(ItemName, CurrentXphyName);
        Lock.savexphy(CurrentXphyName);
        Lock.savefilefolder(SelectedFile, CurrentXphyName);
        Lock.setfocus();

        connect(&Lock,
                &lockunlockDialog::eventsignal,
                this,
                &MainWindow::log_event);

        Lock.exec();
    }
    else
    {
        QMediaPlayer *music = new QMediaPlayer(this);
        music->setMedia(QUrl::fromLocalFile("../../resources/media/SmokeAlarm.wav"));
        music->setVolume(50);
        music->play();

        QString logmsg, pw;
        logmsg = CurrentXphyName;
        QString date = QDate::currentDate().toString("MM/dd/yyyy");
        QString time = QTime::currentTime().toString("hh:mm:ss");
        logmsg = QString(logmsg).append("--> "+date);
        logmsg = QString(logmsg).append("  "+time);
        pw = "Lock/Unlock feature, Invalid Password has reached its limit!";
        logmsg = QString(logmsg).append("  "+pw);
        log_event(logmsg);
    }

    return;
}

#if BACKEND_ENABLE
#include <flexxlib.h>
flexxon::flexxDriveList driveList;

//static const int namespace_size = 1*1024*1024*1024; // 1GB

void MainWindow::initializebackend(void)
{
//    flexxon::flexxDriveList driveList;


    static flexxon::flexxDriveList::iterator disk;
    struct identify_controller_struct id_control;
    struct identify_namespace_struct id_namespace;
//    struct create_ns_template_struct create_ns;
//    struct lba_formatx_struct *flbaPtr;
//    uint32_t new_nsid;/
    std::vector<struct log_err_info_struct> err_info;
    struct log_smart_info_struct smart_info_global;
//    struct log_smart_info_struct smart_info_ns;
//    struct log_fw_slot_info_struct fw_slot;

    scan_devices(driveList);

    for (disk = driveList.begin(); disk < driveList.end(); disk++) {
            memset(&id_control, 0, sizeof(id_control));
            memset(&id_namespace, 0, sizeof(id_namespace));

            disk->identify(id_control);
            disk->identify(id_namespace);
            //disk->logpage(err_info, 1);
            disk->logpage(1, smart_info_global);
//            disk->logpage(0, smart_info_ns);
            //disk->logpage(fw_slot);
    }


    int lbasizeidx = id_namespace.flbas;    // formatted lba size
    int lbasize = 1 << id_namespace.lbaf[lbasizeidx].lbads;

    double diskcapinbytes = id_namespace.ncap/lbasize;
    uint64_t sizegb = diskcapinbytes/(1024*4);

    double totcapacity = (512 * 1024) * 1024;
    uint64_t freespace = (sizegb * 1024) * 1024;
    uint64_t remaining = totcapacity - freespace;

    // free space
    QString sizegigabyte = QString::number(sizegb);
//    ui->label_44->setStyleSheet("color: yellow");
//    ui->label_44->setText(sizegigabyte+" GB");
    ui->label_54->setStyleSheet("color: yellow");
    ui->label_54->setText(sizegigabyte+" GB");

    // used space
    QString remaindrive = QString::number(remaining);
//    ui->label_51->setStyleSheet("color: yellow");
//    ui->label_51->setText(remaindrive+" B");
    ui->label_60->setStyleSheet("color: yellow");
    ui->label_60->setText(remaindrive+" B");

/*    // temperature
    uint32_t comptemp = xphyhealth[0].info1;
    comptemp = (comptemp & INFO1_COMPOSITE_TEMP_MASK) >> 8;
    float temp = comptemp - 273.15; // kelvin to celcius
    QString compositetemp = QString::number(temp);
    ui->label_50->setStyleSheet("color: yellow");
    ui->label_50->setText(compositetemp+" 'C");
*/

    get_smart_health_info(smart_info_global);
    get_identify_controller(id_control);


/*    QString logmess = "Smart Health information -->";
    logmess = QString(logmess).append(QString::number(configDialog->configdata->cfgoption[0].xphyhealth.avail_spare_threshold));
    log_event(logmess);
*/
#if 0
    /* try sending create namespace once to the drive */
    disk = driveList.begin();
    disk->identify(0xffffffff, cns_idns, &id_namespace, sizeof(id_namespace));
    flbaPtr = &id_namespace.lbaf[0];
    create_ns.nsze = namespace_size / (1 << flbaPtr->lbads);
    create_ns.ncap = create_ns.nsze;
    create_ns.flbas = 0;
    disk->create_namespace(create_ns, new_nsid);
#endif
}

void MainWindow::get_identify_controller(identify_controller_struct id_control)
{

    // check xphy or device name this identify controller is
    // scsi1, or scsi2
//    CurrentXphyName

    // firmware revision
    QString firmrev;
    for (int i = 0; i < 8; i++)
    {        
        identifycontlr[0].fr[i] = id_control.fr[i];
        uint8_t fr = identifycontlr[0].fr[i];
        char firm = static_cast<char>(fr);
        firmrev[i] = firm;
    }
    ui->label_16->setStyleSheet("color: yellow");
    ui->label_16->setText(firmrev);

    QString modelnum;
    for (int i = 0; i < 40; i++)
    {
        identifycontlr[0].mn[i] = id_control.mn[i];
        uint8_t mn = identifycontlr[0].mn[i];
        char modelno = static_cast<char>(mn);
        modelnum[i] = modelno;
    }
    ui->label_17->setStyleSheet("color: yellow");
    ui->label_17->setText(modelnum);

    QString serialnum;
    for (int i = 0; i < 20; i++)
    {
        identifycontlr[0].sn[i] = id_control.sn[i];
        uint8_t sn = identifycontlr[0].sn[i];
        char serialno = static_cast<char>(sn);
        serialnum[i] = serialno;
    }
    ui->label_36->setStyleSheet("color: yellow");
    ui->label_36->setText(serialnum);

/*    QString cntlid;
    for (int i = 0; i < 2; i++)
    {
        identifycontlr[0].cntlid[i] = id_control.cntlid[i];
        uint8_t cid = identifycontlr[0].cntlid[i];
        char cntlrid = static_cast<char>(cid);
        cntlid[i] = cntlrid;
    }
    ui->label_18->setText(cntlid);
*/
    identifycontlr[0].cntlid[0] = id_control.cntlid[0];
    uint8_t cid = identifycontlr[0].cntlid[0];
    QString cntlid1 = QString::number(cid);

    identifycontlr[0].cntlid[1] = id_control.cntlid[1];
    uint8_t cid2 = identifycontlr[0].cntlid[1];
    QString cntlid2 = QString::number(cid2);
    QString cntlid = QString(cntlid1).append(cntlid2);
    ui->label_18->setStyleSheet("color: yellow");
    ui->label_18->setText(cntlid);

    identifycontlr[0].ssvid = id_control.ssvid;
    uint16_t ssvid = identifycontlr[0].ssvid;
    QString ssvidstr = QString::number(ssvid);
    ui->label_34->setStyleSheet("color: yellow");
    ui->label_34->setText(ssvidstr);

    identifycontlr[0].vid = id_control.vid;
    uint16_t vid = identifycontlr[0].vid;
    QString vidstr = QString::number(vid);
    ui->label_42->setStyleSheet("color: yellow");
    ui->label_42->setText(vidstr);

    identifycontlr[0].ver.mjr = id_control.ver.mjr;
    identifycontlr[0].ver.mnr = id_control.ver.mnr;
    identifycontlr[0].ver.ter = id_control.ver.ter;

    QString major, minor, terstr;
    uint16_t mjr = identifycontlr[0].ver.mjr;
    uint8_t mnr = identifycontlr[0].ver.mnr;
    uint8_t tert = identifycontlr[0].ver.ter;
    major = QString::number(mjr);
    minor = QString::number(mnr);
    terstr = QString::number(tert);
    QString version = QString(major).append(minor).append(terstr);
    ui->label_31->setStyleSheet("color: yellow");
    ui->label_31->setText(version);

    identifycontlr[0].nn = id_control.nn;
    uint32_t nn = identifycontlr[0].nn;
    QString nnstr = QString::number(nn);
    ui->label_19->setStyleSheet("color: yellow");
    ui->label_19->setText(nnstr);

    identifycontlr[0].npss = id_control.npss;
    uint8_t npss = identifycontlr[0].npss;
    QString npssstr = QString::number(npss);
    ui->label_20->setStyleSheet("color: yellow");
    ui->label_20->setText(npssstr);

    identifycontlr[0].nvscc = id_control.nvscc;
    uint8_t nvncc = identifycontlr[0].nvscc;
    QString nvnccstr = QString::number(nvncc);
    ui->label_24->setStyleSheet("color: yellow");
    ui->label_24->setText(nvnccstr);

    identifycontlr[0].oacs = id_control.oacs;
    uint16_t oacs = identifycontlr[0].oacs;
    QString oacsstr = QString::number(oacs);
    ui->label_21->setStyleSheet("color: yellow");
    ui->label_21->setText(oacsstr);

    identifycontlr[0].oaes = id_control.oaes;
    uint32_t oaes = identifycontlr[0].oaes;
    QString oaesstr = QString::number(oaes);
    ui->label_22->setStyleSheet("color: yellow");
    ui->label_22->setText(oaesstr);

    identifycontlr[0].oncs = id_control.oncs;
    uint16_t oncs = identifycontlr[0].oncs;
    QString oncsstr = QString::number(oncs);
    ui->label_29->setStyleSheet("color: yellow");
    ui->label_29->setText(oncsstr);

    identifycontlr[0].rab = id_control.rab;
    uint16_t rab = identifycontlr[0].rab;
    QString rabstr = QString::number(rab);
    ui->label_27->setStyleSheet("color: yellow");
    ui->label_27->setText(rabstr);

    identifycontlr[0].rpmbs = id_control.rpmbs;
    uint32_t rpmbs = identifycontlr[0].rpmbs;
    QString rpmbsstr = QString::number(rpmbs);
    ui->label_28->setStyleSheet("color: yellow");
    ui->label_28->setText(rpmbsstr);

    identifycontlr[0].rtd3e = id_control.rtd3e;
    uint32_t rtd3e = identifycontlr[0].rtd3e;
    QString rtd3estr = QString::number(rtd3e);
    ui->label_26->setStyleSheet("color: yellow");
    ui->label_26->setText(rtd3estr);

    identifycontlr[0].rtd3r = id_control.rtd3r;
    uint32_t rtd3r = identifycontlr[0].rtd3r;
    QString rtd3rstr = QString::number(rtd3r);
    ui->label_23->setStyleSheet("color: yellow");
    ui->label_23->setText(rtd3rstr);

    QString tnvmcaphi, tnvmcaplo;
    identifycontlr[0].tnvmcap.hi = id_control.tnvmcap.hi;
    identifycontlr[0].tnvmcap.lo = id_control.tnvmcap.lo;
    uint64_t hi = identifycontlr[0].tnvmcap.hi;
    uint64_t lo = identifycontlr[0].tnvmcap.lo;
    tnvmcaphi = QString::number(hi);
    tnvmcaplo = QString::number(lo);
    QString tnvmhi = QString(tnvmcaphi).append(tnvmcaplo);
    ui->label_32->setStyleSheet("color: yellow");
    ui->label_32->setText(rtd3rstr);

    QString unvmcaphi, unvmcaplo;
    identifycontlr[0].unvmcap.hi = id_control.unvmcap.hi;
    identifycontlr[0].unvmcap.lo = id_control.unvmcap.lo;
    uint64_t unvmhi = identifycontlr[0].unvmcap.hi;
    uint64_t unvmlo = identifycontlr[0].unvmcap.lo;
    unvmcaphi = QString::number(unvmhi);
    unvmcaplo = QString::number(unvmlo);
    QString unvm = QString(unvmcaphi).append(unvmcaplo);
    ui->label_30->setStyleSheet("color: yellow");
    ui->label_30->setText(unvm);

    QString subnqnstr;
//    for (int i = 0; i < 256; i++)
    for (int i = 0; i < 32; i++)
    {
        identifycontlr[0].subnqn[i] = id_control.subnqn[i];

        uint8_t subnqn = identifycontlr[0].subnqn[i];
        char subnqno = static_cast<char>(subnqn);
        subnqnstr[i] = subnqno;
    }
    ui->label_33->setStyleSheet("color: yellow");
    ui->label_33->setText(subnqnstr);

    identifycontlr[0].sqes = id_control.sqes;
    uint8_t sqes = identifycontlr[0].sqes;
    QString sqesstr = QString::number(sqes);
    ui->label_35->setStyleSheet("color: yellow");
    ui->label_35->setText(sqesstr);

    identifycontlr[0].sanicap = id_control.sanicap;
    uint32_t sanicap = identifycontlr[0].sanicap;
    QString sanicapstr = QString::number(sanicap);
    ui->label_25->setStyleSheet("color: yellow");
    ui->label_25->setText(sanicapstr);

    identifycontlr[0].vwc = id_control.vwc;
    uint32_t vwc = identifycontlr[0].vwc;
    QString vwcstr = QString::number(vwc);
    ui->label_41->setStyleSheet("color: yellow");
    ui->label_41->setText(vwcstr);

    QString ieeestr;
    for (int i = 0; i < 3; i++)
    {
        identifycontlr[0].ieee[i] = id_control.ieee[i];

        uint8_t ieee = identifycontlr[0].ieee[i];
        char ieeest = static_cast<char>(ieee);
        ieeestr[i] = ieeest;
    }
    ui->label_37->setStyleSheet("color: yellow");
    ui->label_37->setText(ieeestr);

    identifycontlr[0].kas = id_control.kas;
    uint16_t kas = identifycontlr[0].kas;
    QString kasstr = QString::number(kas);
    ui->label_40->setStyleSheet("color: yellow");
    ui->label_40->setText(kasstr);

    identifycontlr[0].lpa = id_control.lpa;
    uint16_t lpa = identifycontlr[0].lpa;
    QString lpastr = QString::number(lpa);
    ui->label_38->setStyleSheet("color: yellow");
    ui->label_38->setText(lpastr);

    identifycontlr[0].maxcmd = id_control.maxcmd;
    uint16_t maxcmd = identifycontlr[0].maxcmd;
    QString maxcmdstr = QString::number(maxcmd);
    ui->label_39->setStyleSheet("color: yellow");
    ui->label_39->setText(maxcmdstr);

    identifycontlr[0].mntmt = id_control.mntmt;
    uint16_t mntmt = identifycontlr[0].mntmt;
    QString mntmtstr = QString::number(mntmt);
    ui->label_48->setStyleSheet("color: yellow");
    ui->label_48->setText(mntmtstr);

    identifycontlr[0].mxtmt= id_control.mxtmt;
    uint16_t mxtmt = identifycontlr[0].mxtmt;
    QString mxtmtstr = QString::number(mxtmt);
    ui->label_47->setStyleSheet("color: yellow");
    ui->label_47->setText(mxtmtstr);

    identifycontlr[0].acl= id_control.acl;
    uint8_t acl =  identifycontlr[0].acl;
    QString abortcmdlimit = QString::number(acl);
    ui->label_72->setStyleSheet("color: yellow");
    ui->label_72->setText(abortcmdlimit);

    identifycontlr[0].aerl= id_control.aerl;
    uint8_t aerl =  identifycontlr[0].aerl;
    QString asyncherL = QString::number(aerl);
    ui->label_43->setStyleSheet("color: yellow");
    ui->label_43->setText(asyncherL);

    identifycontlr[0].elpe= id_control.elpe;
    uint8_t elpe =  identifycontlr[0].elpe;
    QString errorlpe = QString::number(elpe);
    ui->label_45->setStyleSheet("color: yellow");
    ui->label_45->setText(errorlpe);

    identifycontlr[0].avscc= id_control.avscc;
    uint8_t avscc =  identifycontlr[0].avscc;
    QString adminvscc = QString::number(avscc);
    ui->label_49->setStyleSheet("color: yellow");
    ui->label_49->setText(adminvscc);

    // use this as temperature
/*    identifycontlr[0].psdx[0].rwl = id_control.psdx[0].rwl;
    uint16_t rwl = identifycontlr[0].psdx[0].rwl;
    QString rwlstr = QString::number(rwl);
    ui->label_50->setText(rwlstr);
*/

    uint32_t comptemp = xphyhealth[0].info1;
    comptemp = (comptemp & INFO1_COMPOSITE_TEMP_MASK) >> 8;
    float temp = comptemp - 273.15; // kelvin to celcius
    QString compositetemp = QString::number(temp);
//    ui->label_50->setStyleSheet("color: yellow");
//    ui->label_50->setText(compositetemp+" 'C");
    ui->label_13->setStyleSheet("color: yellow");
    ui->label_13->setText(compositetemp+" 'C");

/*    // used space
    identifycontlr[0].psdx[0].rwt = id_control.psdx[0].rwt;
    uint16_t rwt = identifycontlr[0].psdx[0].rwt;
    QString rwtstr = QString::number(rwt);temp
    ui->label_51->setText(rwtstr);

    // free space
    identifycontlr[0].psdx[0].rrl = id_control.psdx[0].rrl;
    uint16_t rrl = identifycontlr[0].psdx[0].rrl;
    QString rrlstr = QString::number(rrl);
    ui->label_44->setText(rrlstr);
*/

/* change with temperature, used, free
    identifycontlr.psdx[0].aps_apw = id_control.psdx[0].aps_apw;
    uint8_t aps_apw = identifycontlr.psdx[0].aps_apw;
    QString aps_apwstr = QString::number(aps_apw);
    ui->label_43->setText(aps_apwstr);

    identifycontlr.psdx[0].actp = id_control.psdx[0].actp;
    uint16_t actp = identifycontlr.psdx[0].actp;
    QString actpstr = QString::number(actp);
    ui->label_45->setText(actpstr);

    identifycontlr.psdx[0].idlp = id_control.psdx[0].idlp;
    uint16_t idlp = identifycontlr.psdx[0].idlp;
    QString idlpstr = QString::number(idlp);
    ui->label_49->setText(idlpstr);
*/

    // same thing with namespace, display used space, free space, and temperature

    #if 0
    // too much information to display to 1 tab
    configDialog->configdata->cfgoption[0].identifycontlr.psdx[i].mp = id_control.psdx[i].mp;
    configDialog->configdata->cfgoption[0].identifycontlr.psdx[i].nops_mxps = id_control.psdx[i].nops_mxps;
    configDialog->configdata->cfgoption[0].identifycontlr.psdx[i].enlat = id_control.psdx[i].enlat;
    configDialog->configdata->cfgoption[0].identifycontlr.psdx[i].exlat = id_control.psdx[i].exlat;
    configDialog->configdata->cfgoption[0].identifycontlr.psdx[i].rrt = id_control.psdx[i].rrt;
    configDialog->configdata->cfgoption[0].identifycontlr.psdx[i].rrl = id_control.psdx[i].rrl;

    for (int i = 0; i < 40; i++)
    {
        configDialog->configdata->cfgoption[0].identifycontlr.mn[i] = id_control.mn[i];

        uint64_t mn = configDialog->configdata->cfgoption[0].identifycontlr.mn[i];
        QString model = QString::number(mn);
        model = QString(model).append(model);
    }

    configDialog->configdata->cfgoption[0].identifycontlr.cmic = id_control.cmic;
    configDialog->configdata->cfgoption[0].identifycontlr.mdts = id_control.mdts;

    configDialog->configdata->cfgoption[0].identifycontlr.ctratt = id_control.ctratt;

    for (int i = 0; i < 16; i++)
    {
        configDialog->configdata->cfgoption[0].identifycontlr.fguid[i] = id_control.fguid[i];

        uint64_t fguid = configDialog->configdata->cfgoption[0].identifycontlr.fguid[i];
        QString fguidstr = QString::number(fguid);
        fguidstr = QString(fguidstr).append(fguidstr);
    }

    configDialog->configdata->cfgoption[0].identifycontlr.frmw = id_control.frmw;
    configDialog->configdata->cfgoption[0].identifycontlr.elpe = id_control.elpe;
    configDialog->configdata->cfgoption[0].identifycontlr.npss = id_control.npss;
    configDialog->configdata->cfgoption[0].identifycontlr.avscc = id_control.avscc;
    configDialog->configdata->cfgoption[0].identifycontlr.apsta = id_control.apsta;
    configDialog->configdata->cfgoption[0].identifycontlr.wctemp= id_control.wctemp;
    configDialog->configdata->cfgoption[0].identifycontlr.cctemp = id_control.cctemp;
    configDialog->configdata->cfgoption[0].identifycontlr.mtfa = id_control.mtfa;
    configDialog->configdata->cfgoption[0].identifycontlr.hmpre = id_control.hmpre;
    configDialog->configdata->cfgoption[0].identifycontlr.hmmin = id_control.hmmin;
    configDialog->configdata->cfgoption[0].identifycontlr.edstt = id_control.edstt;
    configDialog->configdata->cfgoption[0].identifycontlr.dsto = id_control.dsto;
    configDialog->configdata->cfgoption[0].identifycontlr.hctma = id_control.hctma;
    configDialog->configdata->cfgoption[0].identifycontlr.cqes = id_control.cqes;
    configDialog->configdata->cfgoption[0].identifycontlr.nn = id_control.nn;
    configDialog->configdata->cfgoption[0].identifycontlr.fuses = id_control.fuses;
    configDialog->configdata->cfgoption[0].identifycontlr.fna = id_control.fna;
    configDialog->configdata->cfgoption[0].identifycontlr.awun = id_control.awun;
    configDialog->configdata->cfgoption[0].identifycontlr.awupf = id_control.awupf;
    configDialog->configdata->cfgoption[0].identifycontlr.acwu = id_control.acwu;
    configDialog->configdata->cfgoption[0].identifycontlr.sgls = id_control.sgls;

    for (int i = 0; i < 1024; i++)
    {
        configDialog->configdata->cfgoption[0].identifycontlr.vs[i] = id_control.vs[i];

        uint64_t vendorspec = configDialog->configdata->cfgoption[0].identifycontlr.vs[i];
        QString vendorspecstr = QString::number(vendorspec);
        vendorspecstr = QString(vendorspecstr).append(vendorspecstr);
    }
    #endif
}

void MainWindow::get_smart_health_info(log_smart_info_struct smart_info_global)
{
    // smart health information
    QString logmsg;

    // check which xphy

    xphyhealth[0].info1 = smart_info_global.info1;

    uint32_t critwarning = xphyhealth[0].info1;
    critwarning = critwarning & INFO1_CRITICAL_WARNING_MASK;
    QString critwarn = QString::number(critwarning);
    ui->label_46->setStyleSheet("color: yellow");
    ui->label_46->setText(critwarn);

    uint32_t comptemp = xphyhealth[0].info1;
    comptemp = (comptemp & INFO1_COMPOSITE_TEMP_MASK) >> 8;
    QString compositetemp = QString::number(comptemp);
    ui->label_52->setStyleSheet("color: yellow");
    ui->label_52->setText(compositetemp);

    uint32_t availspare = xphyhealth[0].info1;
    availspare = (availspare & INFO1_AVAIL_SPARE_MAKE) >> 24;
    QString availsparetemp = QString::number(availspare);
    ui->label_53->setStyleSheet("color: yellow");
    ui->label_53->setText(availsparetemp);

    /* in graph
    xphyhealth[0].avail_spare_threshold = smart_info_global.avail_spare_threshold;
    uint8_t availthresh = xphyhealth[0].avail_spare_threshold;
    QString availthreshold = QString::number(availthresh);
    ui->label_54->setStyleSheet("color: yellow");
    ui->label_54->setText(availthreshold);
    */

    xphyhealth[0].percentage_used = smart_info_global.percentage_used;
    uint8_t percentuse = xphyhealth[0].percentage_used;
    QString percentused = QString::number(percentuse);
    ui->label_55->setStyleSheet("color: yellow");
    ui->label_55->setText(percentused);

    xphyhealth[0].data_units_read.hi = smart_info_global.data_units_read.hi;
    xphyhealth[0].data_units_read.lo = smart_info_global.data_units_read.lo;
//    uint64_t dataunitsrd = xphyhealth[0].data_units_read.hi;
//    QString dataunitsrdhi = QString::number(dataunitsrd);
    uint64_t dataunitsread = xphyhealth[0].data_units_read.lo;
    QString dataunitsreadlo = QString::number(dataunitsread);
//    QString dataunitsreadall = QString(dataunitsrdhi).append(dataunitsreadlo);
    ui->label_56->setStyleSheet("color: yellow");
    ui->label_56->setText(dataunitsreadlo);

    xphyhealth[0].data_units_written.hi = smart_info_global.data_units_written.hi;
    xphyhealth[0].data_units_written.lo = smart_info_global.data_units_written.lo;
//    uint64_t dataunitswr = xphyhealth[0].data_units_written.hi;
//    QString dataunitswrhi = QString::number(dataunitswr);
    uint64_t dataunitswrite = xphyhealth[0].data_units_written.lo;
    QString dataunitswritelo = QString::number(dataunitswrite);
//    QString dataunitsreadall = QString(dataunitsrdhi).append(dataunitsreadlo);
    ui->label_57->setStyleSheet("color: yellow");
    ui->label_57->setText(dataunitswritelo);

    xphyhealth[0].host_read_commands.hi = smart_info_global.host_read_commands.hi;
    xphyhealth[0].host_read_commands.lo = smart_info_global.host_read_commands.lo;
//    uint64_t hostrdcmd = xphyhealth[0].host_read_commands.hi;
//    QString hostrdcmdhi = QString::number(hostrdcmd);
    uint64_t hostreadcmd = xphyhealth[0].host_read_commands.lo;
    QString hostreadcmdlo = QString::number(hostreadcmd);
//    QString dataunitsreadall = QString(dataunitsrdhi).append(dataunitsreadlo);
    ui->label_58->setStyleSheet("color: yellow");
    ui->label_58->setText(hostreadcmdlo);

    xphyhealth[0].host_write_commands.hi = smart_info_global.host_write_commands.hi;
    xphyhealth[0].host_write_commands.lo = smart_info_global.host_write_commands.lo;
//    uint64_t hostrwcmd = xphyhealth[0].host_write_commands.hi;
//    QString hostrwcmdhi = QString::number(hostrdcmd);
    uint64_t hostwritecmd = xphyhealth[0].host_write_commands.lo;
    QString hostwritecmdlo = QString::number(hostwritecmd);
//    QString dataunitsreadall = QString(dataunitsrdhi).append(dataunitsreadlo);
    ui->label_59->setStyleSheet("color: yellow");
    ui->label_59->setText(hostwritecmdlo);

    /* in graph
    xphyhealth[0].controller_busy_time.hi = smart_info_global.controller_busy_time.hi;
    xphyhealth[0].controller_busy_time.lo = smart_info_global.controller_busy_time.lo;
//    uint64_t contbusytime = xphyhealth[0].controller_busy_time.hi;
//    QString contbusytimehi = QString::number(contbusytime);
    uint64_t controlbusytime = xphyhealth[0].controller_busy_time.lo;
    QString controlbusytimelo = QString::number(controlbusytime);
//    QString dataunitsreadall = QString(dataunitsrdhi).append(dataunitsreadlo);
    ui->label_60->setStyleSheet("color: yellow");
    ui->label_60->setText(controlbusytimelo);
    */

    /* in graph
    xphyhealth[0].power_cycles.hi = smart_info_global.power_cycles.hi;
    xphyhealth[0].power_cycles.lo = smart_info_global.power_cycles.lo;
//    uint64_t powercycle = xphyhealth[0].power_cycles.hi;
//    QString powercyclehi = QString::number(powercycle);
    uint64_t powercyc = xphyhealth[0].power_cycles.lo;
    QString powercyclo = QString::number(powercyc);
//    QString dataunitsreadall = QString(dataunitsrdhi).append(dataunitsreadlo);
    ui->label_61->setStyleSheet("color: yellow");
    ui->label_61->setText(powercyclo);
    */

    xphyhealth[0].power_on_hours.hi = smart_info_global.power_on_hours.hi;
    xphyhealth[0].power_on_hours.lo = smart_info_global.power_on_hours.lo;
//    uint64_t poweronhr = xphyhealth[0].power_on_hours.hi;
//    QString poweronhrhi = QString::number(poweronhr);
    uint64_t poweronhour = xphyhealth[0].power_on_hours.lo;
    QString poweronhourlo = QString::number(poweronhour);
//    QString dataunitsreadall = QString(dataunitsrdhi).append(dataunitsreadlo);
    ui->label_62->setStyleSheet("color: yellow");
    ui->label_62->setText(poweronhourlo);

    /* in graph
    xphyhealth[0].unsafe_shutdowns.hi = smart_info_global.unsafe_shutdowns.hi;
    xphyhealth[0].unsafe_shutdowns.lo = smart_info_global.unsafe_shutdowns.lo;
//    uint64_t unsafeshut = xphyhealth[0].unsafe_shutdowns.hi;
//    QString contbusytimehi = QString::number(contbusytime);
    uint64_t unsafeshutdown = xphyhealth[0].unsafe_shutdowns.lo;
    QString unsafeshutdownlo = QString::number(unsafeshutdown);
//    QString dataunitsreadall = QString(dataunitsrdhi).append(dataunitsreadlo);
    ui->label_63->setStyleSheet("color: yellow");
    ui->label_63->setText(unsafeshutdownlo);
    */

    xphyhealth[0].data_integrity_errors.hi = smart_info_global.data_integrity_errors.hi;
    xphyhealth[0].data_integrity_errors.lo = smart_info_global.data_integrity_errors.lo;
//    uint64_t datainterr = xphyhealth[0].data_integrity_errors.hi;
//    QString datainterrhi = QString::number(contbusytime);
    uint64_t datainterror = xphyhealth[0].data_integrity_errors.lo;
    QString datainterrorlo = QString::number(datainterror);
//    QString dataunitsreadall = QString(dataunitsrdhi).append(dataunitsreadlo);
    ui->label_64->setStyleSheet("color: yellow");
    ui->label_64->setText(datainterrorlo);

    /* in graph
    xphyhealth[0].number_of_error_info_log_entries.hi = smart_info_global.number_of_error_info_log_entries.hi;
    xphyhealth[0].number_of_error_info_log_entries.lo = smart_info_global.number_of_error_info_log_entries.lo;
//    uint64_t numberlog = xphyhealth[0].number_of_error_info_log_entries.hi;
//    QString numberloghi = QString::number(contbusytime);
    uint64_t numberlogerr = xphyhealth[0].number_of_error_info_log_entries.lo;
    QString numberlogerrlo = QString::number(numberlogerr);
//    QString dataunitsreadall = QString(dataunitsrdhi).append(dataunitsreadlo);
    ui->label_65->setStyleSheet("color: yellow");
    ui->label_65->setText(numberlogerrlo);
    */

    xphyhealth[0].warning_composite_temp_time = smart_info_global.warning_composite_temp_time;
    uint32_t warncomptemptime = xphyhealth[0].warning_composite_temp_time;
    QString warningcomptemptime = QString::number(warncomptemptime);
    ui->label_66->setStyleSheet("color: yellow");
    ui->label_66->setText(warningcomptemptime);

    xphyhealth[0].critical_composite_temp_time = smart_info_global.critical_composite_temp_time;
    uint32_t critcomptemptime = xphyhealth[0].critical_composite_temp_time;
    QString criticalcomptemptime = QString::number(critcomptemptime);
    ui->label_67->setStyleSheet("color: yellow");
    ui->label_67->setText(criticalcomptemptime);

    xphyhealth[0].temp_sensor[0].tst = smart_info_global.temp_sensor[0].tst;
    uint16_t tempsensor = xphyhealth[0].temp_sensor[0].tst;
    QString tempsensor1 = QString::number(tempsensor);
    ui->label_68->setStyleSheet("color: yellow");
    ui->label_68->setText(tempsensor1);


/*
    uint64_t dataunitswrhi = xphyhealth[0].data_units_written.hi;
    QString dataunitwrittenhi = QString::number(dataunitswrhi);
    uint64_t dataunitswrlo = xphyhealth[0].data_units_written.lo;
    QString dataunitwrittenlo = QString::number(dataunitswrlo);
    QString dataunitswritten = QString(dataunitwrittenhi).append(dataunitwrittenlo);
    ui->label_54->setText(dataunitswritten);

    uint64_t hostrdhi = xphyhealth[0].host_read_commands.hi;
    QString hostreadhi = QString::number(hostrdhi);
    uint64_t hostrdlo = xphyhealth[0].host_read_commands.lo;
    QString hostreadlo = QString::number(hostrdlo);
    QString hostread = QString(hostreadhi).append(hostreadlo);
    ui->label_55->setText(hostread);


    uint64_t dataunitsrdhi = xphyhealth[0].data_units_read.hi;
    QString dataunitsreadhi = QString::number(dataunitsrdhi);
    uint64_t dataunitsrdlo = xphyhealth[0].data_units_read.lo;
    QString dataunitsreadlo = QString::number(dataunitsrdlo);
    QString dataunitsread = QString(dataunitsreadhi).append(dataunitsreadlo);
    ui->label_53->setText(dataunitsread);
*/

/*
    xphyhealth[0].temp_sensor[0].tst = smart_info_global.temp_sensor[0].tst;
    xphyhealth[0].temp_sensor[1].tst = smart_info_global.temp_sensor[1].tst;
    xphyhealth[0].temp_sensor[2].tst = smart_info_global.temp_sensor[2].tst;
    xphyhealth[0].temp_sensor[3].tst = smart_info_global.temp_sensor[3].tst;
    xphyhealth[0].temp_sensor[4].tst = smart_info_global.temp_sensor[4].tst;
    xphyhealth[0].temp_sensor[5].tst = smart_info_global.temp_sensor[5].tst;
    xphyhealth[0].temp_sensor[6].tst = smart_info_global.temp_sensor[6].tst;
    xphyhealth[0].temp_sensor[7].tst = smart_info_global.temp_sensor[7].tst;

    xphyhealth[0].thermal_mgmt_temp_transition_count[0] = smart_info_global.thermal_mgmt_temp_transition_count[0];
    xphyhealth[0].thermal_mgmt_temp_transition_count[1] = smart_info_global.thermal_mgmt_temp_transition_count[1];

    xphyhealth[0].total_time_for_thermal_mgmt_temp[0] = smart_info_global.total_time_for_thermal_mgmt_temp[0];
    xphyhealth[0].total_time_for_thermal_mgmt_temp[1] = smart_info_global.total_time_for_thermal_mgmt_temp[1];

*/



/*
    uint64_t hostrdhi = xphyhealth[0].host_read_commands.hi;
    QString hostreadhi = QString::number(hostrdhi);
    uint64_t hostrdlo = xphyhealth[0].host_read_commands.lo;
    QString hostreadlo = QString::number(hostrdlo);
    QString hostread = QString(hostreadhi).append(hostreadlo);
    ui->label_55->setText(hostread);

    uint64_t hostwrhi = xphyhealth[0].host_write_commands.hi;
    QString hostwritehi = QString::number(hostwrhi);
    uint64_t hostwrlo = xphyhealth[0].host_write_commands.lo;
    QString hostwritelo = QString::number(hostwrlo);
    QString hostwrite = QString(hostwritehi).append(hostwritelo);
    ui->label_56->setText(hostwrite);

    uint64_t cntrbusyrhi = xphyhealth[0].controller_busy_time.hi;
    QString cntrbusyhistr = QString::number(cntrbusyrhi);
    uint64_t cntrbusylo = xphyhealth[0].controller_busy_time.lo;
    QString cntrbusylostr = QString::number(cntrbusylo);
    QString cntrbusy = QString(cntrbusyhistr).append(cntrbusylostr);
    ui->label_57->setText(cntrbusy);

    uint64_t powercyclehrhi = xphyhealth[0].power_on_hours.hi;
    QString powercyclehrhistr = QString::number(powercyclehrhi);
    uint64_t powercyclehrlo = xphyhealth[0].power_on_hours.lo;
    QString powercyclehrlostr = QString::number(powercyclehrlo);
    QString powercyclehr = QString(powercyclehrhistr).append(powercyclehrlostr);
    ui->label_58->setText(powercyclehr);

    uint64_t wctemptime = xphyhealth[0].warning_composite_temp_time;
    QString wctemptimestr = QString::number(wctemptime);
    ui->label_59->setText(wctemptimestr);

    uint64_t cctemptime = xphyhealth[0].critical_composite_temp_time;
    QString cctemptimestr = QString::number(cctemptime);
    ui->label_60->setText(cctemptimestr);

    uint64_t tempsensor1 = xphyhealth[0].temp_sensor[0].tst;
    QString tempsensor1str = QString::number(tempsensor1);
    ui->label_61->setText(tempsensor1str);

    uint64_t tempsensor2 = xphyhealth[0].temp_sensor[1].tst;
    QString tempsensor2str = QString::number(tempsensor2);
    ui->label_62->setText(tempsensor2str);

    uint64_t tempsensor3 = xphyhealth[0].temp_sensor[2].tst;
    QString tempsensor3str = QString::number(tempsensor3);
    ui->label_63->setText(tempsensor3str);

    uint64_t tempsensor4 = xphyhealth[0].temp_sensor[3].tst;
    QString tempsensor4str = QString::number(tempsensor4);
    ui->label_64->setText(tempsensor4str);

    uint64_t tempsensor5 = xphyhealth[0].temp_sensor[4].tst;
    QString tempsensor5str = QString::number(tempsensor5);
    ui->label_65->setText(tempsensor5str);

    uint64_t tempsensor6 = xphyhealth[0].temp_sensor[5].tst;
    QString tempsensor6str = QString::number(tempsensor6);
    ui->label_66->setText(tempsensor6str);

    uint64_t tempsensor7 = xphyhealth[0].temp_sensor[6].tst;
    QString tempsensor7str = QString::number(tempsensor7);
    ui->label_67->setText(tempsensor7str);

    uint64_t tempsensor8 = xphyhealth[0].temp_sensor[7].tst;
    QString tempsensor8str = QString::number(tempsensor8);
    ui->label_68->setText(tempsensor8str);
*/

}
/*
void MainWindow::updateprogress()
{
    ui->progressBar->show();

    progressval++;

    ui->progressBar->setValue(progressval);
}
*/
#endif
