#include "verifypwdialog.h"
#include "ui_verifypwdialog.h"
#include <QMessageBox>

verifyfwDialog::verifyfwDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::verifyfwDialog)
{
    ui->setupUi(this);
}

verifyfwDialog::~verifyfwDialog()
{
    delete ui;
}

void verifyfwDialog::SetFocus(void)
{
    ui->lineEdit->setFocus();
}



void verifyfwDialog::on_pushButton_clicked()
{
/*    QString Namespace;
    Namespace = "namespace";

    if (ui->lineEdit->text() == NULL)
    {
        QMessageBox::information(this,
                                 "Password",
                                 "No Input Password!");
    }
    else
    {
        for (int i = 0; i < 8; i++)
        {
            if (CurrItemName == QString(Namespace).append((QString::number(i+1))))
            {
                pwmainwindowdata[i] = ui->lineEdit->text();
                //pwdata.Password1 pwdata = ui->lineEdit->text();
            }
        }

        QMessageBox::information(this,
                                 "Password",
                                 "Password has been Changed!");
    }*/
    return;
}
