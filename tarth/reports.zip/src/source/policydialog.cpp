#include "policydialog.h"
#include "ui_policydialog.h"
#include <QMessageBox>
#include <QDateTime>
#include <QDateTime>
#include <QMediaPlayer>
#include <QFile>
#include <QMutex>

policyDialog::policyDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::policyDialog)
{
    ui->setupUi(this);

    progressbar = new QProgressBar();
    ui->progressBar->setMinimum(0);
    ui->progressBar->setMaximum(100);
    ui->progressBar->hide();
    progressval = 0;

    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()),
            this, SLOT(updateprogress()));

    timer->start(1000);

}

policyDialog::~policyDialog()
{
    delete ui;
}

void policyDialog::savenamespace(QString ns)
{
    policyitemns = ns;
}

void policyDialog::savephxy(QString xphy)
{
    policyitemxphy = xphy;

    if (xphy == "XPHY1")
    {
        setcomboitem(0);
    }
    else
    {
        setcomboitem(1);
    }
}

void policyDialog::setcomboitem(int idx)
{
    ui->comboBox->setCurrentIndex(idx);
}

void policyDialog::savedata(CONFIG_DATA *ConfigData)
{
    this->ConfigData = ConfigData;
}

void policyDialog::enadiscombobox(bool val)
{
    ui->comboBox->setEnabled(val);
}

void policyDialog::enadiscomboboxns(bool val)
{
    ui->comboBox_2->setEnabled(val);
}

void policyDialog::enadispbutton(bool val)
{
    ui->pushButton->setEnabled(val);
}

void policyDialog::enadispbuttonns(bool val)
{
    ui->pushButton_2->setEnabled(val);
}

void policyDialog::setcombotext(QString str)
{
    ui->comboBox->addItem(str);
}

void policyDialog::setcombotextns(QString str)
{
    ui->comboBox_2->addItem(str);
}

void policyDialog::setfocus(void)
{
    ui->lineEdit->setFocus();
}

void policyDialog::enadischeckbox(bool val)
{
    ui->checkBox->setEnabled(val);
    ui->checkBox_2->setEnabled(val);
    ui->checkBox_3->setEnabled(val);
    ui->checkBox_4->setEnabled(val);
    ui->checkBox_5->setEnabled(val);
    ui->checkBox_8->setEnabled(val);
}

//#include "flexxlib.h"
//extern flexxon::flexxDriveList driveList;

void policyDialog::on_pushButton_clicked()
{
    QString         FileReport = QString("../../reports/") + "report.csv";
    QFile           ReportFile(FileReport);
    QTextStream     Data(&ReportFile);
    //static QMutex   wait;


    if (ui->comboBox != NULL)
    {
        policyitemxphy = ui->comboBox->currentText();
    }

    if (policyitemxphy == "XPHY1")
    {
        if (ConfigData->cfgoption[0].password == ui->lineEdit->text())
        {
            QMediaPlayer *music = new QMediaPlayer(this);
            music->setMedia(QUrl::fromLocalFile("../../resources/media/passed.mp3"));
            music->setVolume(50);
            music->play();

            enadischeckbox(false);
            ui->comboBox_2->setEnabled(true);
            ui->pushButton_2->setEnabled(true);

            QString logmsg, pw;
            logmsg = ui->comboBox->currentText();
            QString date = QDate::currentDate().toString("MM/dd/yyyy");
            QString time = QTime::currentTime().toString("hh:mm:ss");
            logmsg = QString(logmsg).append("--> "+date);
            logmsg = QString(logmsg).append("  "+time);
            pw = "Password verified passed!";
            logmsg = QString(logmsg).append("  "+pw);
            emit eventsignal(logmsg);

            if (ReportFile.open(QIODevice::WriteOnly | QIODevice::Append))
            {
                Data << QString(REPORT_CONTENTS).arg(date).arg(time).arg(policyitemxphy)
                                                .arg(policyitemns)
                                                .arg(pw);

                ReportFile.close();
            }
            else
            {
                logmsg = "Failed to create a report file!  ";
                logmsg = QString(logmsg).append("  "+time);
                logmsg = QString(logmsg).append("  "+date);
                emit eventsignal(logmsg);
            }
/*
            flexxon::FlexxDecorator flexxdisk(driveList[0]);

            wait.lock();
            flexxdisk.change_policy(const uint32_t policyhi,
                                    const uint32_t policylo,
                                    char *password,
                                    const int psize);
            wait.unlock();
*/
        }
        else
        {
            QMediaPlayer *music = new QMediaPlayer(this);
            music->setMedia(QUrl::fromLocalFile("../../resources/media/ErrorSound.wav"));
            music->setVolume(50);
            music->play();

            // call api here for change policy

            QString logmsg, pw;
            logmsg = ui->comboBox->currentText();
            QString date = QDate::currentDate().toString("MM/dd/yyyy");
            QString time = QTime::currentTime().toString("hh:mm:ss");
            logmsg = QString(logmsg).append("--> "+date);
            logmsg = QString(logmsg).append("  "+time);
            pw = "Password verified failed!";
            logmsg = QString(logmsg).append("  "+pw);
            emit eventsignal(logmsg);

            if (ReportFile.open(QIODevice::WriteOnly | QIODevice::Append))
            {
                Data << QString(REPORT_CONTENTS).arg(date).arg(time).arg(policyitemxphy)
                                                .arg(policyitemns)
                                                .arg(pw);

                ReportFile.close();
            }
            else
            {
                logmsg = "Failed to create a report file!  ";
                logmsg = QString(logmsg).append("  "+time);
                logmsg = QString(logmsg).append("  "+date);
                emit eventsignal(logmsg);
            }
        }
    }
    else
    {
        if (ConfigData->cfgoption[1].password == ui->lineEdit->text())
        {
            QMediaPlayer *music = new QMediaPlayer(this);
            music->setMedia(QUrl::fromLocalFile("../../resources/media/passed.mp3"));
            music->setVolume(50);
            music->play();

            enadischeckbox(true);
            ui->comboBox_2->setEnabled(true);
            ui->pushButton_2->setEnabled(true);

            QString logmsg, pw;
            logmsg= ui->comboBox->currentText();
            QString date = QDate::currentDate().toString("MM/dd/yyyy");
            QString time = QTime::currentTime().toString("hh:mm:ss");
            logmsg = QString(logmsg).append("--> "+date);
            logmsg = QString(logmsg).append("  "+time);
            pw = "Password verified passed!";
            logmsg = QString(logmsg).append("  "+pw);
            emit eventsignal(logmsg);

            if (ReportFile.open(QIODevice::WriteOnly | QIODevice::Append))
            {
                Data << QString(REPORT_CONTENTS).arg(date).arg(time).arg(policyitemxphy)
                                                .arg(policyitemns)
                                                .arg(pw);

                ReportFile.close();
            }
            else
            {
                logmsg = "Failed to create a report file!  ";
                logmsg = QString(logmsg).append("  "+time);
                logmsg = QString(logmsg).append("  "+date);
                emit eventsignal(logmsg);
            }
        }
        else
        {
            QMediaPlayer *music = new QMediaPlayer(this);
            music->setMedia(QUrl::fromLocalFile("../../resources/media/ErrorSound.wav"));
            music->setVolume(50);
            music->play();

            QString logmsg, pw;
            logmsg = ui->comboBox->currentText();
            QString date = QDate::currentDate().toString("MM/dd/yyyy");
            QString time = QTime::currentTime().toString("hh:mm:ss");
            logmsg = QString(logmsg).append("--> "+time);
            logmsg = QString(logmsg).append("  "+date);
            pw = "Password verified failed!";
            logmsg = QString(logmsg).append("  "+pw);
            emit eventsignal(logmsg);

            if (ReportFile.open(QIODevice::WriteOnly | QIODevice::Append))
            {
                Data << QString(REPORT_CONTENTS).arg(date).arg(time).arg(policyitemxphy)
                                                .arg(policyitemns)
                                                .arg(pw);

                ReportFile.close();
            }
            else
            {
                logmsg = "Failed to create a report file!  ";
                logmsg = QString(logmsg).append("  "+time);
                logmsg = QString(logmsg).append("  "+date);
                emit eventsignal(logmsg);
            }
        }
    }

    ui->lineEdit->clear();
    ui->lineEdit->setFocus();
}

void policyDialog::on_pushButton_2_clicked()
{
    // change policy
    QString FileReport = QString("../../reports/") + "report.csv";
    QFile ReportFile(FileReport);
    QTextStream Data(&ReportFile);
//    bool FileExist = false;

    QString state, nsstr, xphystr;
    QString logmsg;
    int nsno;
    int xphyno;

    nsstr = ui->comboBox_2->currentText();          // get ns
    nsno = nsstr.right(nsstr.size()-9).toInt();     // get string number only

    xphystr = ui->comboBox->currentText();          // xphy
    xphyno = xphystr.right(xphystr.size()-4).toInt();
/*
    if (ConfigData->cfgoption[xphyno-1].enablefeature[nsno-1].policy == false)
    {
        logmsg = ui->comboBox->currentText();
        QString date = QDate::currentDate().toString("MM/dd/yyyy");
        QString time = QTime::currentTime().toString("hh:mm:ss");
        logmsg = QString(logmsg).append("--> "+date);
        logmsg = QString(logmsg).append("  "+time);
        logmsg = QString(logmsg).append("  Policy to this");
        logmsg = QString(logmsg).append("  "+nsstr);
        logmsg = QString(logmsg).append("  is disabled");
        emit eventsignal(logmsg);
    }
*/
    QMediaPlayer *music = new QMediaPlayer(this);
    music->setMedia(QUrl::fromLocalFile("../../resources/media/tarakatak.mp3"));
    music->setVolume(50);
    music->play();

    ConfigData->xphy = xphystr;
    ConfigData->cfgoption[xphyno-1].nspace[nsno-1] = nsstr;

    logmsg = ui->comboBox->currentText();
    QString date = QDate::currentDate().toString("MM/dd/yyyy");
    QString time = QTime::currentTime().toString("hh:mm:ss");
    logmsg = QString(logmsg).append("--> "+date);
    logmsg = QString(logmsg).append("  "+time);
    logmsg = QString(logmsg).append("  Change Policies!");
    emit eventsignal(logmsg);

    if (ReportFile.open(QIODevice::WriteOnly | QIODevice::Append))
    {
        Data << QString(REPORT_CONTENTS).arg(date)
                                        .arg(time)
                                        .arg(policyitemxphy)
                                        .arg(policyitemns)
                                        .arg("Change Policies");

        ReportFile.close();
    }
    else
    {
        logmsg = "Failed to create a report file!  ";
        logmsg = QString(logmsg).append("  "+time);
        logmsg = QString(logmsg).append("  "+date);
        emit eventsignal(logmsg);
    }

    // get policy state
    ConfigData->cfgoption[xphyno-1].policies[nsno-1].policy1 = ui->checkBox->checkState();
    if (ui->checkBox->checkState())
    {
        logmsg = "Free space";
        emit eventsignal(logmsg);
    }
    ConfigData->cfgoption[xphyno-1].policies[nsno-1].policy2 = ui->checkBox_2->checkState();
    if (ui->checkBox_2->checkState())
    {
        logmsg = "Temperature";
        emit eventsignal(logmsg);
    }
    ConfigData->cfgoption[xphyno-1].policies[nsno-1].policy3 = ui->checkBox_3->checkState();
    if (ui->checkBox_3->checkState())
    {
        logmsg = "Unsafe Shutdown";
        emit eventsignal(logmsg);
    }
    ConfigData->cfgoption[xphyno-1].policies[nsno-1].policy4 = ui->checkBox_4->checkState();
    if (ui->checkBox_4->checkState())
    {
        logmsg = "Media and Data Integrity Error";
        emit eventsignal(logmsg);
    }
    ConfigData->cfgoption[xphyno-1].policies[nsno-1].policy5 = ui->checkBox_5->checkState();
    if (ui->checkBox_5->checkState())
    {
        logmsg = "Number of error Information log entires";
        emit eventsignal(logmsg);
    }
    ConfigData->cfgoption[xphyno-1].policies[nsno-1].policy6 = ui->checkBox_8->checkState();
    if (ui->checkBox_8->checkState())
    {
        logmsg = "Critical Warning";
        emit eventsignal(logmsg);
    }

    ui->pushButton_2->setEnabled(false);

}

void policyDialog::on_comboBox_2_activated(const QString &arg1)
{
    int nsno, xphyno;
    QString xphystr, nsstr;
    QString logmsg;

    nsno = arg1.right(arg1.size()-9).toInt();

    xphystr = ui->comboBox->currentText();
    xphyno = xphystr.right(xphystr.size()-4).toInt();

    if (ConfigData->cfgoption[xphyno-1].enablefeature[nsno-1].policy == false)
    {
        logmsg = "Policies to this namespace are disable";
        emit eventsignal(logmsg);

        enadischeckbox(false);
        return;
    }

    enadischeckbox(true);
}

void policyDialog::updateprogress()
{
/*    ui->progressBar->show();

    progressval++;
    ui->progressBar->setValue(progressval);*/
}
