/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QTreeView>
#include <QtWidgets/QTreeWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QVBoxLayout *verticalLayout_5;
    QSplitter *splitter_2;
    QWidget *widget;
    QGridLayout *gridLayout_8;
    QSplitter *splitter;
    QTreeWidget *treeWidget;
    QTabWidget *tabWidget;
    QWidget *tab1;
    QGridLayout *gridLayout;
    QWidget *wgtXPHYInfo;
    QGridLayout *gridLayout_5;
    QLabel *label_33;
    QLabel *label_49;
    QLabel *lblModelName_23;
    QLabel *lblModelName;
    QLabel *lblModelName_17;
    QLabel *label_30;
    QLabel *label_28;
    QLabel *label_47;
    QLabel *label_22;
    QLabel *lblModelName_8;
    QLabel *label_25;
    QLabel *lblModelName_7;
    QLabel *label_18;
    QLabel *label_29;
    QLabel *lblModelName_29;
    QLabel *label_45;
    QLabel *lblModelName_18;
    QLabel *label_72;
    QLabel *label_31;
    QLabel *firmwarerevision;
    QLabel *label_36;
    QLabel *label_24;
    QLabel *lblModelName_19;
    QLabel *label_27;
    QLabel *label_26;
    QLabel *lblModelName_24;
    QLabel *lblModelName_27;
    QLabel *label_48;
    QLabel *label_40;
    QLabel *lblModelName_13;
    QLabel *lblModelName_10;
    QLabel *lblModelName_15;
    QLabel *label_35;
    QLabel *lblModelName_12;
    QLabel *lblModelName_4;
    QLabel *lblModelName_30;
    QLabel *lblModelName_20;
    QLabel *lblModelName_6;
    QLabel *lblModelName_16;
    QLabel *label_41;
    QLabel *lblModelName_28;
    QLabel *label_17;
    QLabel *label_16;
    QLabel *label_43;
    QLabel *lblModelName_3;
    QLabel *label_38;
    QLabel *lblModelName_22;
    QLabel *label_39;
    QLabel *lblSerialNumber;
    QLabel *label_20;
    QLabel *lblModelName_25;
    QLabel *label_42;
    QLabel *lblModelName_31;
    QLabel *label_37;
    QLabel *lblModelName_2;
    QLabel *label_21;
    QLabel *lblModelName_11;
    QLabel *label_34;
    QLabel *lblFwVersion;
    QLabel *lblModelName_21;
    QLabel *lblModelName_9;
    QLabel *label_19;
    QLabel *lblModelName_14;
    QLabel *label_32;
    QLabel *lblModelName_5;
    QLabel *label_23;
    QWidget *tab2;
    QGridLayout *gridLayout_2;
    QWidget *wgtHealthInfo;
    QHBoxLayout *horizontalLayout;
    QWidget *widget_2;
    QGridLayout *gridLayout_3;
    QWidget *widget_3;
    QGridLayout *gridLayout_7;
    QScrollArea *scrollArea;
    QWidget *scrollAreaWidgetContents;
    QGridLayout *gridLayout_6;
    QLabel *label_70;
    QLabel *label_64;
    QLabel *label_58;
    QLabel *label_4;
    QLabel *label_67;
    QLabel *label_55;
    QLabel *label_52;
    QLabel *label_3;
    QLabel *label_9;
    QLabel *label_53;
    QLabel *label;
    QLabel *label_6;
    QLabel *label_68;
    QLabel *label_69;
    QLabel *label_56;
    QLabel *label_8;
    QLabel *label_54;
    QLabel *label_57;
    QLabel *label_5;
    QLabel *label_62;
    QLabel *label_2;
    QLabel *label_12;
    QLabel *label_46;
    QLabel *label_7;
    QLabel *label_60;
    QLabel *label_71;
    QLabel *label_59;
    QLabel *label_14;
    QLabel *label_66;
    QLabel *label_10;
    QLabel *label_11;
    QLabel *label_13;
    QWidget *tab;
    QGridLayout *gridLayout_4;
    QWidget *wgtLockUnlock;
    QVBoxLayout *verticalLayout_6;
    QTreeView *treeView;
    QPushButton *pushButton;
    QTextBrowser *textBrowser;
    QProgressBar *progressBar;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1019, 687);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/icons/icons/flexxon.png"), QSize(), QIcon::Normal, QIcon::Off);
        MainWindow->setWindowIcon(icon);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        verticalLayout_5 = new QVBoxLayout(centralwidget);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        splitter_2 = new QSplitter(centralwidget);
        splitter_2->setObjectName(QString::fromUtf8("splitter_2"));
        splitter_2->setOrientation(Qt::Vertical);
        widget = new QWidget(splitter_2);
        widget->setObjectName(QString::fromUtf8("widget"));
        gridLayout_8 = new QGridLayout(widget);
        gridLayout_8->setObjectName(QString::fromUtf8("gridLayout_8"));
        gridLayout_8->setContentsMargins(0, 0, 0, 0);
        splitter = new QSplitter(widget);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        splitter->setOrientation(Qt::Horizontal);
        treeWidget = new QTreeWidget(splitter);
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/Images/icons/flexxon.png"), QSize(), QIcon::Normal, QIcon::Off);
        QTreeWidgetItem *__qtreewidgetitem = new QTreeWidgetItem(treeWidget);
        __qtreewidgetitem->setIcon(0, icon1);
        treeWidget->setObjectName(QString::fromUtf8("treeWidget"));
        treeWidget->setMinimumSize(QSize(180, 0));
        treeWidget->setMaximumSize(QSize(180, 16777215));
        splitter->addWidget(treeWidget);
        tabWidget = new QTabWidget(splitter);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        tabWidget->setEnabled(true);
        tabWidget->setMaximumSize(QSize(16777215, 16777215));
        tab1 = new QWidget();
        tab1->setObjectName(QString::fromUtf8("tab1"));
        gridLayout = new QGridLayout(tab1);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        wgtXPHYInfo = new QWidget(tab1);
        wgtXPHYInfo->setObjectName(QString::fromUtf8("wgtXPHYInfo"));
        gridLayout_5 = new QGridLayout(wgtXPHYInfo);
        gridLayout_5->setObjectName(QString::fromUtf8("gridLayout_5"));
        label_33 = new QLabel(wgtXPHYInfo);
        label_33->setObjectName(QString::fromUtf8("label_33"));
        QFont font;
        font.setBold(false);
        font.setWeight(50);
        label_33->setFont(font);

        gridLayout_5->addWidget(label_33, 1, 3, 1, 1);

        label_49 = new QLabel(wgtXPHYInfo);
        label_49->setObjectName(QString::fromUtf8("label_49"));
        label_49->setFont(font);

        gridLayout_5->addWidget(label_49, 14, 3, 1, 1);

        lblModelName_23 = new QLabel(wgtXPHYInfo);
        lblModelName_23->setObjectName(QString::fromUtf8("lblModelName_23"));

        gridLayout_5->addWidget(lblModelName_23, 4, 2, 1, 1);

        lblModelName = new QLabel(wgtXPHYInfo);
        lblModelName->setObjectName(QString::fromUtf8("lblModelName"));

        gridLayout_5->addWidget(lblModelName, 7, 0, 1, 1);

        lblModelName_17 = new QLabel(wgtXPHYInfo);
        lblModelName_17->setObjectName(QString::fromUtf8("lblModelName_17"));

        gridLayout_5->addWidget(lblModelName_17, 2, 2, 1, 1);

        label_30 = new QLabel(wgtXPHYInfo);
        label_30->setObjectName(QString::fromUtf8("label_30"));
        label_30->setFont(font);

        gridLayout_5->addWidget(label_30, 0, 3, 1, 1);

        label_28 = new QLabel(wgtXPHYInfo);
        label_28->setObjectName(QString::fromUtf8("label_28"));
        label_28->setFont(font);

        gridLayout_5->addWidget(label_28, 14, 1, 1, 1);

        label_47 = new QLabel(wgtXPHYInfo);
        label_47->setObjectName(QString::fromUtf8("label_47"));
        label_47->setFont(font);

        gridLayout_5->addWidget(label_47, 10, 3, 1, 1);

        label_22 = new QLabel(wgtXPHYInfo);
        label_22->setObjectName(QString::fromUtf8("label_22"));
        label_22->setFont(font);

        gridLayout_5->addWidget(label_22, 11, 1, 1, 1);

        lblModelName_8 = new QLabel(wgtXPHYInfo);
        lblModelName_8->setObjectName(QString::fromUtf8("lblModelName_8"));

        gridLayout_5->addWidget(lblModelName_8, 15, 0, 1, 1);

        label_25 = new QLabel(wgtXPHYInfo);
        label_25->setObjectName(QString::fromUtf8("label_25"));
        label_25->setFont(font);

        gridLayout_5->addWidget(label_25, 3, 3, 1, 1);

        lblModelName_7 = new QLabel(wgtXPHYInfo);
        lblModelName_7->setObjectName(QString::fromUtf8("lblModelName_7"));

        gridLayout_5->addWidget(lblModelName_7, 3, 2, 1, 1);

        label_18 = new QLabel(wgtXPHYInfo);
        label_18->setObjectName(QString::fromUtf8("label_18"));
        label_18->setFont(font);

        gridLayout_5->addWidget(label_18, 3, 1, 1, 1);

        label_29 = new QLabel(wgtXPHYInfo);
        label_29->setObjectName(QString::fromUtf8("label_29"));
        label_29->setFont(font);

        gridLayout_5->addWidget(label_29, 12, 1, 1, 1);

        lblModelName_29 = new QLabel(wgtXPHYInfo);
        lblModelName_29->setObjectName(QString::fromUtf8("lblModelName_29"));

        gridLayout_5->addWidget(lblModelName_29, 10, 2, 1, 1);

        label_45 = new QLabel(wgtXPHYInfo);
        label_45->setObjectName(QString::fromUtf8("label_45"));
        label_45->setFont(font);

        gridLayout_5->addWidget(label_45, 13, 3, 1, 1);

        lblModelName_18 = new QLabel(wgtXPHYInfo);
        lblModelName_18->setObjectName(QString::fromUtf8("lblModelName_18"));

        gridLayout_5->addWidget(lblModelName_18, 2, 0, 1, 1);

        label_72 = new QLabel(wgtXPHYInfo);
        label_72->setObjectName(QString::fromUtf8("label_72"));
        label_72->setFont(font);

        gridLayout_5->addWidget(label_72, 11, 3, 1, 1);

        label_31 = new QLabel(wgtXPHYInfo);
        label_31->setObjectName(QString::fromUtf8("label_31"));
        label_31->setFont(font);

        gridLayout_5->addWidget(label_31, 6, 1, 1, 1);

        firmwarerevision = new QLabel(wgtXPHYInfo);
        firmwarerevision->setObjectName(QString::fromUtf8("firmwarerevision"));

        gridLayout_5->addWidget(firmwarerevision, 0, 0, 1, 1);

        label_36 = new QLabel(wgtXPHYInfo);
        label_36->setObjectName(QString::fromUtf8("label_36"));
        label_36->setFont(font);

        gridLayout_5->addWidget(label_36, 2, 1, 1, 1);

        label_24 = new QLabel(wgtXPHYInfo);
        label_24->setObjectName(QString::fromUtf8("label_24"));
        label_24->setFont(font);

        gridLayout_5->addWidget(label_24, 9, 1, 1, 1);

        lblModelName_19 = new QLabel(wgtXPHYInfo);
        lblModelName_19->setObjectName(QString::fromUtf8("lblModelName_19"));

        gridLayout_5->addWidget(lblModelName_19, 5, 2, 1, 1);

        label_27 = new QLabel(wgtXPHYInfo);
        label_27->setObjectName(QString::fromUtf8("label_27"));
        label_27->setFont(font);

        gridLayout_5->addWidget(label_27, 13, 1, 1, 1);

        label_26 = new QLabel(wgtXPHYInfo);
        label_26->setObjectName(QString::fromUtf8("label_26"));
        label_26->setFont(font);

        gridLayout_5->addWidget(label_26, 15, 1, 1, 1);

        lblModelName_24 = new QLabel(wgtXPHYInfo);
        lblModelName_24->setObjectName(QString::fromUtf8("lblModelName_24"));

        gridLayout_5->addWidget(lblModelName_24, 5, 0, 1, 1);

        lblModelName_27 = new QLabel(wgtXPHYInfo);
        lblModelName_27->setObjectName(QString::fromUtf8("lblModelName_27"));

        gridLayout_5->addWidget(lblModelName_27, 13, 2, 1, 1);

        label_48 = new QLabel(wgtXPHYInfo);
        label_48->setObjectName(QString::fromUtf8("label_48"));
        label_48->setFont(font);

        gridLayout_5->addWidget(label_48, 9, 3, 1, 1);

        label_40 = new QLabel(wgtXPHYInfo);
        label_40->setObjectName(QString::fromUtf8("label_40"));
        label_40->setFont(font);

        gridLayout_5->addWidget(label_40, 6, 3, 1, 1);

        lblModelName_13 = new QLabel(wgtXPHYInfo);
        lblModelName_13->setObjectName(QString::fromUtf8("lblModelName_13"));

        gridLayout_5->addWidget(lblModelName_13, 6, 0, 1, 1);

        lblModelName_10 = new QLabel(wgtXPHYInfo);
        lblModelName_10->setObjectName(QString::fromUtf8("lblModelName_10"));

        gridLayout_5->addWidget(lblModelName_10, 14, 0, 1, 1);

        lblModelName_15 = new QLabel(wgtXPHYInfo);
        lblModelName_15->setObjectName(QString::fromUtf8("lblModelName_15"));

        gridLayout_5->addWidget(lblModelName_15, 1, 2, 1, 1);

        label_35 = new QLabel(wgtXPHYInfo);
        label_35->setObjectName(QString::fromUtf8("label_35"));
        label_35->setFont(font);

        gridLayout_5->addWidget(label_35, 2, 3, 1, 1);

        lblModelName_12 = new QLabel(wgtXPHYInfo);
        lblModelName_12->setObjectName(QString::fromUtf8("lblModelName_12"));

        gridLayout_5->addWidget(lblModelName_12, 0, 2, 1, 1);

        lblModelName_4 = new QLabel(wgtXPHYInfo);
        lblModelName_4->setObjectName(QString::fromUtf8("lblModelName_4"));

        gridLayout_5->addWidget(lblModelName_4, 11, 0, 1, 1);

        lblModelName_30 = new QLabel(wgtXPHYInfo);
        lblModelName_30->setObjectName(QString::fromUtf8("lblModelName_30"));

        gridLayout_5->addWidget(lblModelName_30, 9, 2, 1, 1);

        lblModelName_20 = new QLabel(wgtXPHYInfo);
        lblModelName_20->setObjectName(QString::fromUtf8("lblModelName_20"));

        gridLayout_5->addWidget(lblModelName_20, 7, 2, 1, 1);

        lblModelName_6 = new QLabel(wgtXPHYInfo);
        lblModelName_6->setObjectName(QString::fromUtf8("lblModelName_6"));

        gridLayout_5->addWidget(lblModelName_6, 9, 0, 1, 1);

        lblModelName_16 = new QLabel(wgtXPHYInfo);
        lblModelName_16->setObjectName(QString::fromUtf8("lblModelName_16"));

        gridLayout_5->addWidget(lblModelName_16, 4, 0, 1, 1);

        label_41 = new QLabel(wgtXPHYInfo);
        label_41->setObjectName(QString::fromUtf8("label_41"));
        label_41->setFont(font);

        gridLayout_5->addWidget(label_41, 4, 3, 1, 1);

        lblModelName_28 = new QLabel(wgtXPHYInfo);
        lblModelName_28->setObjectName(QString::fromUtf8("lblModelName_28"));

        gridLayout_5->addWidget(lblModelName_28, 11, 2, 1, 1);

        label_17 = new QLabel(wgtXPHYInfo);
        label_17->setObjectName(QString::fromUtf8("label_17"));
        label_17->setFont(font);

        gridLayout_5->addWidget(label_17, 1, 1, 1, 1);

        label_16 = new QLabel(wgtXPHYInfo);
        label_16->setObjectName(QString::fromUtf8("label_16"));
        label_16->setFont(font);

        gridLayout_5->addWidget(label_16, 0, 1, 1, 1);

        label_43 = new QLabel(wgtXPHYInfo);
        label_43->setObjectName(QString::fromUtf8("label_43"));
        label_43->setFont(font);

        gridLayout_5->addWidget(label_43, 12, 3, 1, 1);

        lblModelName_3 = new QLabel(wgtXPHYInfo);
        lblModelName_3->setObjectName(QString::fromUtf8("lblModelName_3"));

        gridLayout_5->addWidget(lblModelName_3, 10, 0, 1, 1);

        label_38 = new QLabel(wgtXPHYInfo);
        label_38->setObjectName(QString::fromUtf8("label_38"));
        label_38->setFont(font);

        gridLayout_5->addWidget(label_38, 7, 3, 1, 1);

        lblModelName_22 = new QLabel(wgtXPHYInfo);
        lblModelName_22->setObjectName(QString::fromUtf8("lblModelName_22"));

        gridLayout_5->addWidget(lblModelName_22, 6, 2, 1, 1);

        label_39 = new QLabel(wgtXPHYInfo);
        label_39->setObjectName(QString::fromUtf8("label_39"));
        label_39->setFont(font);

        gridLayout_5->addWidget(label_39, 8, 3, 1, 1);

        lblSerialNumber = new QLabel(wgtXPHYInfo);
        lblSerialNumber->setObjectName(QString::fromUtf8("lblSerialNumber"));

        gridLayout_5->addWidget(lblSerialNumber, 3, 0, 1, 1);

        label_20 = new QLabel(wgtXPHYInfo);
        label_20->setObjectName(QString::fromUtf8("label_20"));
        label_20->setFont(font);

        gridLayout_5->addWidget(label_20, 8, 1, 1, 1);

        lblModelName_25 = new QLabel(wgtXPHYInfo);
        lblModelName_25->setObjectName(QString::fromUtf8("lblModelName_25"));

        gridLayout_5->addWidget(lblModelName_25, 12, 2, 1, 1);

        label_42 = new QLabel(wgtXPHYInfo);
        label_42->setObjectName(QString::fromUtf8("label_42"));
        label_42->setFont(font);

        gridLayout_5->addWidget(label_42, 5, 1, 1, 1);

        lblModelName_31 = new QLabel(wgtXPHYInfo);
        lblModelName_31->setObjectName(QString::fromUtf8("lblModelName_31"));

        gridLayout_5->addWidget(lblModelName_31, 14, 2, 1, 1);

        label_37 = new QLabel(wgtXPHYInfo);
        label_37->setObjectName(QString::fromUtf8("label_37"));
        label_37->setFont(font);

        gridLayout_5->addWidget(label_37, 5, 3, 1, 1);

        lblModelName_2 = new QLabel(wgtXPHYInfo);
        lblModelName_2->setObjectName(QString::fromUtf8("lblModelName_2"));

        gridLayout_5->addWidget(lblModelName_2, 8, 0, 1, 1);

        label_21 = new QLabel(wgtXPHYInfo);
        label_21->setObjectName(QString::fromUtf8("label_21"));
        label_21->setFont(font);

        gridLayout_5->addWidget(label_21, 10, 1, 1, 1);

        lblModelName_11 = new QLabel(wgtXPHYInfo);
        lblModelName_11->setObjectName(QString::fromUtf8("lblModelName_11"));

        gridLayout_5->addWidget(lblModelName_11, 12, 0, 1, 1);

        label_34 = new QLabel(wgtXPHYInfo);
        label_34->setObjectName(QString::fromUtf8("label_34"));
        label_34->setFont(font);

        gridLayout_5->addWidget(label_34, 4, 1, 1, 1);

        lblFwVersion = new QLabel(wgtXPHYInfo);
        lblFwVersion->setObjectName(QString::fromUtf8("lblFwVersion"));

        gridLayout_5->addWidget(lblFwVersion, 1, 0, 1, 1);

        lblModelName_21 = new QLabel(wgtXPHYInfo);
        lblModelName_21->setObjectName(QString::fromUtf8("lblModelName_21"));

        gridLayout_5->addWidget(lblModelName_21, 8, 2, 1, 1);

        lblModelName_9 = new QLabel(wgtXPHYInfo);
        lblModelName_9->setObjectName(QString::fromUtf8("lblModelName_9"));

        gridLayout_5->addWidget(lblModelName_9, 13, 0, 1, 1);

        label_19 = new QLabel(wgtXPHYInfo);
        label_19->setObjectName(QString::fromUtf8("label_19"));
        label_19->setFont(font);

        gridLayout_5->addWidget(label_19, 7, 1, 1, 1);

        lblModelName_14 = new QLabel(wgtXPHYInfo);
        lblModelName_14->setObjectName(QString::fromUtf8("lblModelName_14"));

        gridLayout_5->addWidget(lblModelName_14, 15, 2, 1, 1);

        label_32 = new QLabel(wgtXPHYInfo);
        label_32->setObjectName(QString::fromUtf8("label_32"));
        label_32->setFont(font);

        gridLayout_5->addWidget(label_32, 15, 3, 1, 1);

        lblModelName_5 = new QLabel(wgtXPHYInfo);
        lblModelName_5->setObjectName(QString::fromUtf8("lblModelName_5"));

        gridLayout_5->addWidget(lblModelName_5, 17, 0, 1, 1);

        label_23 = new QLabel(wgtXPHYInfo);
        label_23->setObjectName(QString::fromUtf8("label_23"));
        label_23->setFont(font);

        gridLayout_5->addWidget(label_23, 17, 1, 1, 1);


        gridLayout->addWidget(wgtXPHYInfo, 1, 0, 1, 1);

        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/icons/icons/ssd.png"), QSize(), QIcon::Normal, QIcon::Off);
        tabWidget->addTab(tab1, icon2, QString());
        tab2 = new QWidget();
        tab2->setObjectName(QString::fromUtf8("tab2"));
        gridLayout_2 = new QGridLayout(tab2);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        gridLayout_2->setContentsMargins(0, 0, 0, 0);
        wgtHealthInfo = new QWidget(tab2);
        wgtHealthInfo->setObjectName(QString::fromUtf8("wgtHealthInfo"));
        horizontalLayout = new QHBoxLayout(wgtHealthInfo);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        widget_2 = new QWidget(wgtHealthInfo);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        widget_2->setMaximumSize(QSize(16777215, 16777215));
        gridLayout_3 = new QGridLayout(widget_2);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        gridLayout_3->setContentsMargins(0, 0, 0, 0);

        horizontalLayout->addWidget(widget_2);

        widget_3 = new QWidget(wgtHealthInfo);
        widget_3->setObjectName(QString::fromUtf8("widget_3"));
        widget_3->setMaximumSize(QSize(250, 16777215));
        gridLayout_7 = new QGridLayout(widget_3);
        gridLayout_7->setObjectName(QString::fromUtf8("gridLayout_7"));
        gridLayout_7->setContentsMargins(0, 0, 0, 0);
        scrollArea = new QScrollArea(widget_3);
        scrollArea->setObjectName(QString::fromUtf8("scrollArea"));
        scrollArea->setMinimumSize(QSize(180, 0));
        scrollArea->setMaximumSize(QSize(16777215, 16777215));
        scrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents = new QWidget();
        scrollAreaWidgetContents->setObjectName(QString::fromUtf8("scrollAreaWidgetContents"));
        scrollAreaWidgetContents->setGeometry(QRect(0, 0, 248, 397));
        gridLayout_6 = new QGridLayout(scrollAreaWidgetContents);
        gridLayout_6->setObjectName(QString::fromUtf8("gridLayout_6"));
        label_70 = new QLabel(scrollAreaWidgetContents);
        label_70->setObjectName(QString::fromUtf8("label_70"));

        gridLayout_6->addWidget(label_70, 16, 0, 1, 1);

        label_64 = new QLabel(scrollAreaWidgetContents);
        label_64->setObjectName(QString::fromUtf8("label_64"));
        QFont font1;
        font1.setBold(true);
        font1.setWeight(75);
        label_64->setFont(font1);

        gridLayout_6->addWidget(label_64, 14, 1, 1, 1, Qt::AlignHCenter);

        label_58 = new QLabel(scrollAreaWidgetContents);
        label_58->setObjectName(QString::fromUtf8("label_58"));
        label_58->setFont(font1);

        gridLayout_6->addWidget(label_58, 10, 1, 1, 1, Qt::AlignHCenter);

        label_4 = new QLabel(scrollAreaWidgetContents);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        gridLayout_6->addWidget(label_4, 1, 0, 1, 1);

        label_67 = new QLabel(scrollAreaWidgetContents);
        label_67->setObjectName(QString::fromUtf8("label_67"));
        label_67->setFont(font1);

        gridLayout_6->addWidget(label_67, 16, 1, 1, 1, Qt::AlignHCenter);

        label_55 = new QLabel(scrollAreaWidgetContents);
        label_55->setObjectName(QString::fromUtf8("label_55"));
        label_55->setFont(font1);

        gridLayout_6->addWidget(label_55, 7, 1, 1, 1, Qt::AlignHCenter);

        label_52 = new QLabel(scrollAreaWidgetContents);
        label_52->setObjectName(QString::fromUtf8("label_52"));
        label_52->setFont(font1);

        gridLayout_6->addWidget(label_52, 4, 1, 1, 1, Qt::AlignHCenter);

        label_3 = new QLabel(scrollAreaWidgetContents);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout_6->addWidget(label_3, 5, 0, 1, 1);

        label_9 = new QLabel(scrollAreaWidgetContents);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        gridLayout_6->addWidget(label_9, 11, 0, 1, 1);

        label_53 = new QLabel(scrollAreaWidgetContents);
        label_53->setObjectName(QString::fromUtf8("label_53"));
        label_53->setFont(font1);

        gridLayout_6->addWidget(label_53, 5, 1, 1, 1, Qt::AlignHCenter);

        label = new QLabel(scrollAreaWidgetContents);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout_6->addWidget(label, 3, 0, 1, 1);

        label_6 = new QLabel(scrollAreaWidgetContents);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        gridLayout_6->addWidget(label_6, 8, 0, 1, 1);

        label_68 = new QLabel(scrollAreaWidgetContents);
        label_68->setObjectName(QString::fromUtf8("label_68"));
        label_68->setFont(font1);

        gridLayout_6->addWidget(label_68, 17, 1, 1, 1, Qt::AlignHCenter);

        label_69 = new QLabel(scrollAreaWidgetContents);
        label_69->setObjectName(QString::fromUtf8("label_69"));

        gridLayout_6->addWidget(label_69, 17, 0, 1, 1);

        label_56 = new QLabel(scrollAreaWidgetContents);
        label_56->setObjectName(QString::fromUtf8("label_56"));
        label_56->setFont(font1);

        gridLayout_6->addWidget(label_56, 8, 1, 1, 1, Qt::AlignHCenter);

        label_8 = new QLabel(scrollAreaWidgetContents);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        gridLayout_6->addWidget(label_8, 10, 0, 1, 1);

        label_54 = new QLabel(scrollAreaWidgetContents);
        label_54->setObjectName(QString::fromUtf8("label_54"));
        label_54->setFont(font1);

        gridLayout_6->addWidget(label_54, 1, 1, 1, 1, Qt::AlignHCenter);

        label_57 = new QLabel(scrollAreaWidgetContents);
        label_57->setObjectName(QString::fromUtf8("label_57"));
        label_57->setFont(font1);

        gridLayout_6->addWidget(label_57, 9, 1, 1, 1, Qt::AlignHCenter);

        label_5 = new QLabel(scrollAreaWidgetContents);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        gridLayout_6->addWidget(label_5, 7, 0, 1, 1);

        label_62 = new QLabel(scrollAreaWidgetContents);
        label_62->setObjectName(QString::fromUtf8("label_62"));
        label_62->setFont(font1);

        gridLayout_6->addWidget(label_62, 13, 1, 1, 1, Qt::AlignHCenter);

        label_2 = new QLabel(scrollAreaWidgetContents);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout_6->addWidget(label_2, 4, 0, 1, 1);

        label_12 = new QLabel(scrollAreaWidgetContents);
        label_12->setObjectName(QString::fromUtf8("label_12"));

        gridLayout_6->addWidget(label_12, 13, 0, 1, 1);

        label_46 = new QLabel(scrollAreaWidgetContents);
        label_46->setObjectName(QString::fromUtf8("label_46"));
        label_46->setFont(font1);
        label_46->setToolTipDuration(4);

        gridLayout_6->addWidget(label_46, 3, 1, 1, 1, Qt::AlignHCenter);

        label_7 = new QLabel(scrollAreaWidgetContents);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        gridLayout_6->addWidget(label_7, 9, 0, 1, 1);

        label_60 = new QLabel(scrollAreaWidgetContents);
        label_60->setObjectName(QString::fromUtf8("label_60"));
        label_60->setFont(font1);

        gridLayout_6->addWidget(label_60, 0, 1, 1, 1, Qt::AlignHCenter);

        label_71 = new QLabel(scrollAreaWidgetContents);
        label_71->setObjectName(QString::fromUtf8("label_71"));

        gridLayout_6->addWidget(label_71, 15, 0, 1, 1);

        label_59 = new QLabel(scrollAreaWidgetContents);
        label_59->setObjectName(QString::fromUtf8("label_59"));
        label_59->setFont(font1);

        gridLayout_6->addWidget(label_59, 11, 1, 1, 1, Qt::AlignHCenter);

        label_14 = new QLabel(scrollAreaWidgetContents);
        label_14->setObjectName(QString::fromUtf8("label_14"));

        gridLayout_6->addWidget(label_14, 14, 0, 1, 1);

        label_66 = new QLabel(scrollAreaWidgetContents);
        label_66->setObjectName(QString::fromUtf8("label_66"));
        label_66->setFont(font1);

        gridLayout_6->addWidget(label_66, 15, 1, 1, 1, Qt::AlignHCenter);

        label_10 = new QLabel(scrollAreaWidgetContents);
        label_10->setObjectName(QString::fromUtf8("label_10"));

        gridLayout_6->addWidget(label_10, 0, 0, 1, 1);

        label_11 = new QLabel(scrollAreaWidgetContents);
        label_11->setObjectName(QString::fromUtf8("label_11"));

        gridLayout_6->addWidget(label_11, 2, 0, 1, 1);

        label_13 = new QLabel(scrollAreaWidgetContents);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setFont(font1);

        gridLayout_6->addWidget(label_13, 2, 1, 1, 1, Qt::AlignHCenter);

        scrollArea->setWidget(scrollAreaWidgetContents);

        gridLayout_7->addWidget(scrollArea, 0, 0, 1, 1);


        horizontalLayout->addWidget(widget_3);


        gridLayout_2->addWidget(wgtHealthInfo, 0, 0, 1, 1);

        QIcon icon3;
        icon3.addFile(QString::fromUtf8(":/icons/icons/healthinfo.png"), QSize(), QIcon::Normal, QIcon::Off);
        tabWidget->addTab(tab2, icon3, QString());
        tab = new QWidget();
        tab->setObjectName(QString::fromUtf8("tab"));
        gridLayout_4 = new QGridLayout(tab);
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        gridLayout_4->setContentsMargins(-1, 9, -1, -1);
        wgtLockUnlock = new QWidget(tab);
        wgtLockUnlock->setObjectName(QString::fromUtf8("wgtLockUnlock"));
        verticalLayout_6 = new QVBoxLayout(wgtLockUnlock);
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        verticalLayout_6->setContentsMargins(0, 0, 0, 0);
        treeView = new QTreeView(wgtLockUnlock);
        treeView->setObjectName(QString::fromUtf8("treeView"));
        treeView->setRootIsDecorated(false);
        treeView->setSortingEnabled(true);

        verticalLayout_6->addWidget(treeView);

        pushButton = new QPushButton(wgtLockUnlock);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setEnabled(false);
        QFont font2;
        font2.setPointSize(12);
        font2.setBold(true);
        font2.setWeight(75);
        pushButton->setFont(font2);

        verticalLayout_6->addWidget(pushButton);


        gridLayout_4->addWidget(wgtLockUnlock, 0, 0, 1, 1);

        QIcon icon4;
        icon4.addFile(QString::fromUtf8(":/icons/icons/drive.png"), QSize(), QIcon::Normal, QIcon::Off);
        tabWidget->addTab(tab, icon4, QString());
        splitter->addWidget(tabWidget);

        gridLayout_8->addWidget(splitter, 0, 0, 1, 1);

        splitter_2->addWidget(widget);
        textBrowser = new QTextBrowser(splitter_2);
        textBrowser->setObjectName(QString::fromUtf8("textBrowser"));
        textBrowser->setMaximumSize(QSize(16777215, 150));
        splitter_2->addWidget(textBrowser);

        verticalLayout_5->addWidget(splitter_2);

        progressBar = new QProgressBar(centralwidget);
        progressBar->setObjectName(QString::fromUtf8("progressBar"));
        progressBar->setValue(0);

        verticalLayout_5->addWidget(progressBar);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 1019, 21));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "Flexxon Pte Ltd", nullptr));
        QTreeWidgetItem *___qtreewidgetitem = treeWidget->headerItem();
        ___qtreewidgetitem->setText(0, QCoreApplication::translate("MainWindow", "XPHY Detected", nullptr));

        const bool __sortingEnabled = treeWidget->isSortingEnabled();
        treeWidget->setSortingEnabled(false);
        QTreeWidgetItem *___qtreewidgetitem1 = treeWidget->topLevelItem(0);
        ___qtreewidgetitem1->setText(0, QCoreApplication::translate("MainWindow", "XPHY Devices", nullptr));
        treeWidget->setSortingEnabled(__sortingEnabled);

        label_33->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        label_49->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        lblModelName_23->setText(QCoreApplication::translate("MainWindow", "Volatile Wr Cache:", nullptr));
        lblModelName->setText(QCoreApplication::translate("MainWindow", "Namespace No.:", nullptr));
        lblModelName_17->setText(QCoreApplication::translate("MainWindow", "SQES:", nullptr));
        label_30->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        label_28->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        label_47->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        label_22->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        lblModelName_8->setText(QCoreApplication::translate("MainWindow", "RTD3e:", nullptr));
        label_25->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        lblModelName_7->setText(QCoreApplication::translate("MainWindow", "Sanitize Cap:", nullptr));
        label_18->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        label_29->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        lblModelName_29->setText(QCoreApplication::translate("MainWindow", "Max Thermal:", nullptr));
        label_45->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        lblModelName_18->setText(QCoreApplication::translate("MainWindow", "Serial Number:", nullptr));
        label_72->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        label_31->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        firmwarerevision->setText(QCoreApplication::translate("MainWindow", "Firmware Revision:", nullptr));
        label_36->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        label_24->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        lblModelName_19->setText(QCoreApplication::translate("MainWindow", "IEEE:", nullptr));
        label_27->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        label_26->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        lblModelName_24->setText(QCoreApplication::translate("MainWindow", "VID:", nullptr));
        lblModelName_27->setText(QCoreApplication::translate("MainWindow", "ELPE:", nullptr));
        label_48->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        label_40->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        lblModelName_13->setText(QCoreApplication::translate("MainWindow", "Version:", nullptr));
        lblModelName_10->setText(QCoreApplication::translate("MainWindow", "RPMBS:", nullptr));
        lblModelName_15->setText(QCoreApplication::translate("MainWindow", "SUBNQN:", nullptr));
        label_35->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        lblModelName_12->setText(QCoreApplication::translate("MainWindow", "Unallocated NVM:", nullptr));
        lblModelName_4->setText(QCoreApplication::translate("MainWindow", "OAES:", nullptr));
        lblModelName_30->setText(QCoreApplication::translate("MainWindow", "Min Thermal:", nullptr));
        lblModelName_20->setText(QCoreApplication::translate("MainWindow", "Log Page Attr:", nullptr));
        lblModelName_6->setText(QCoreApplication::translate("MainWindow", "NVSCC:", nullptr));
        lblModelName_16->setText(QCoreApplication::translate("MainWindow", "SSVID:", nullptr));
        label_41->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        lblModelName_28->setText(QCoreApplication::translate("MainWindow", "ACL:", nullptr));
        label_17->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        label_16->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        label_43->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        lblModelName_3->setText(QCoreApplication::translate("MainWindow", "OACS:", nullptr));
        label_38->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        lblModelName_22->setText(QCoreApplication::translate("MainWindow", "Keep Alive Support:", nullptr));
        label_39->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        lblSerialNumber->setText(QCoreApplication::translate("MainWindow", "Controller Id:", nullptr));
        label_20->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        lblModelName_25->setText(QCoreApplication::translate("MainWindow", "AERL:", nullptr));
        label_42->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        lblModelName_31->setText(QCoreApplication::translate("MainWindow", "AVSCC:", nullptr));
        label_37->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        lblModelName_2->setText(QCoreApplication::translate("MainWindow", "NPSS:", nullptr));
        label_21->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        lblModelName_11->setText(QCoreApplication::translate("MainWindow", "ONCS:", nullptr));
        label_34->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        lblFwVersion->setText(QCoreApplication::translate("MainWindow", "Model Number:", nullptr));
        lblModelName_21->setText(QCoreApplication::translate("MainWindow", "Maximum Cmd:", nullptr));
        lblModelName_9->setText(QCoreApplication::translate("MainWindow", "RAB:", nullptr));
        label_19->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        lblModelName_14->setText(QCoreApplication::translate("MainWindow", "Total NVM Cap:", nullptr));
        label_32->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        lblModelName_5->setText(QCoreApplication::translate("MainWindow", "RTD3r:", nullptr));
        label_23->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab1), QCoreApplication::translate("MainWindow", "XPHY Info", nullptr));
        label_70->setText(QCoreApplication::translate("MainWindow", "Critical Comp Temp:", nullptr));
        label_64->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        label_58->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "Free Space:", nullptr));
        label_67->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        label_55->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        label_52->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "Avail Spare (Percent):", nullptr));
        label_9->setText(QCoreApplication::translate("MainWindow", "Host Write Cmds:", nullptr));
        label_53->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "Critical Warning:", nullptr));
        label_6->setText(QCoreApplication::translate("MainWindow", "Data Units Rd:", nullptr));
        label_68->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        label_69->setText(QCoreApplication::translate("MainWindow", "Temp Sensor 1:", nullptr));
        label_56->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        label_8->setText(QCoreApplication::translate("MainWindow", "Host Read Cmds:", nullptr));
        label_54->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        label_57->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        label_5->setText(QCoreApplication::translate("MainWindow", "Percentage Used:", nullptr));
        label_62->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "Composite Temp:", nullptr));
        label_12->setText(QCoreApplication::translate("MainWindow", "Power On Hours:", nullptr));
        label_46->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        label_7->setText(QCoreApplication::translate("MainWindow", "Data Units Written:", nullptr));
        label_60->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        label_71->setText(QCoreApplication::translate("MainWindow", "Warning Comp Temp:", nullptr));
        label_59->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        label_14->setText(QCoreApplication::translate("MainWindow", "Media/Data Integ Err:", nullptr));
        label_66->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        label_10->setText(QCoreApplication::translate("MainWindow", "Used Space:", nullptr));
        label_11->setText(QCoreApplication::translate("MainWindow", "Temperature:", nullptr));
        label_13->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab2), QCoreApplication::translate("MainWindow", "Health Info", nullptr));
        pushButton->setText(QCoreApplication::translate("MainWindow", "Lock / Unlock", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab), QCoreApplication::translate("MainWindow", "Namespace Files", nullptr));
        textBrowser->setHtml(QCoreApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p></body></html>", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
