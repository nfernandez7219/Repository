#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <string.h>
#include <vector>
#include "RawDevice.h"
#include "nvme.h"
#include "nvmeIoctl.h"

static std::vector<Device> drives;

#if 0
static void scan_drives(void)
{
        struct TargetType target;
        int i;

        for (i = 0; i < MAX_BLOCK_DEVICES; i++) {
                target.typ = device_type_block;
                sprintf(target.filename, "%s%d:", "\\\\.\\Scsi", i);

                if (!isType(&target, device_type_block)) {
                        continue;
                }

                /* if we reach here we are a block device.
                 * but we are not sure yet if we are scsi
                 * or NVMe at this point.
                 * Create a raw block device object for now.
                 */
                Device d(target);
                drives.push_back(d);
        }
        return;
}
#endif

static const char oldpass[] = "default xphy password";
static const char newpass[] = "Flexxon xphy password";

#include <stddef.h>

int main()
{
        struct TargetType tgt = {
                .filename = "\\\\.\\Scsi1:",
                .typ = device_type_block,
        };
        ADMIN_IDENTIFY_CONTROLLER ctrlid;
        ADMIN_IDENTIFY_NAMESPACE namespaceid;

        Device xphy(tgt);

        xphy.print_name();
        memset(&ctrlid, 0, sizeof(ADMIN_IDENTIFY_CONTROLLER));
        identify_controller(xphy, &ctrlid, sizeof(ADMIN_IDENTIFY_CONTROLLER));


        memset(&namespaceid, 0, sizeof(ADMIN_IDENTIFY_NAMESPACE));
        identify_namespace(xphy, &namespaceid, sizeof(ADMIN_IDENTIFY_NAMESPACE));


        set_xphy_password(xphy, oldpass, newpass);

        return 0;
}
