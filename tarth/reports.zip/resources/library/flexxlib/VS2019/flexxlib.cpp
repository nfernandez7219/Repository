#define _CRT_SECURE_NO_WARNINGS

#include <Windows.h>
#include <ntddscsi.h>

#include "RawDevice.h"
#include "nvme.h"
#include "nvmeIoctl.h"

int isType(struct TargetType *tgt, const int typ)
{
        HANDLE hdl;
        int err = 0;
        DWORD fileType;

        if (tgt && *tgt->filename) {
                hdl = CreateFileA(tgt->filename,
                        GENERIC_READ | GENERIC_WRITE,
                        FILE_SHARE_READ | FILE_SHARE_WRITE,
                        NULL,
                        OPEN_EXISTING,
                        FILE_ATTRIBUTE_NORMAL,
                        NULL);
                if (hdl != INVALID_HANDLE_VALUE) {
                        fileType = GetFileType(hdl);
                        switch (fileType) {
                        case FILE_TYPE_DISK: err = (typ == device_type_block);
                        }
                        CloseHandle(hdl);
                }
        }
        return err;
}

int identify_controller(Device &d, void *buffer, int buffersize)
{
        UCHAR myIoctlBuf[sizeof(NVME_PASS_THROUGH_IOCTL) +
                sizeof(ADMIN_IDENTIFY_CONTROLLER)];
        PNVME_PASS_THROUGH_IOCTL     pMyIoctl = (PNVME_PASS_THROUGH_IOCTL)myIoctlBuf;
        DWORD                        dw;
        PADMIN_IDENTIFY_COMMAND_DW10 dw10;
        PNVMe_COMMAND                pCmd;
        BOOL                         b;
        PADMIN_IDENTIFY_CONTROLLER ident_ctrl = NULL;

        memset(pMyIoctl, 0, sizeof(myIoctlBuf));

        // Set up the SRB IO Control header
        pMyIoctl->SrbIoCtrl.ControlCode = (ULONG)NVME_PASS_THROUGH_SRB_IO_CODE;
        memcpy(pMyIoctl->SrbIoCtrl.Signature, NVME_SIG_STR, sizeof(NVME_SIG_STR));
        pMyIoctl->SrbIoCtrl.HeaderLength = (ULONG)sizeof(SRB_IO_CONTROL);
        pMyIoctl->SrbIoCtrl.Timeout = 30;
        pMyIoctl->SrbIoCtrl.Length = sizeof(myIoctlBuf) - sizeof(SRB_IO_CONTROL);

        // Set up the NVMe pass through IOCTL buffer
        pCmd = (PNVMe_COMMAND)pMyIoctl->NVMeCmd;
        pCmd->CDW0.OPC = ADMIN_IDENTIFY;
        dw10 = (PADMIN_IDENTIFY_COMMAND_DW10) & (pCmd->CDW10);
        dw10->CNS = 1;

        pMyIoctl->QueueId = 0; // Admin queue
        pMyIoctl->DataBufferLen = 0;
        pMyIoctl->Direction = NVME_FROM_DEV_TO_HOST;
        pMyIoctl->ReturnBufferLen = sizeof(ADMIN_IDENTIFY_CONTROLLER) + sizeof(NVME_PASS_THROUGH_IOCTL);
        pMyIoctl->VendorSpecific[0] = (DWORD)0;
        pMyIoctl->VendorSpecific[1] = (DWORD)0;
        memset(pMyIoctl->DataBuffer, 0x55, sizeof(ADMIN_IDENTIFY_CONTROLLER));

        ident_ctrl = (PADMIN_IDENTIFY_CONTROLLER)pMyIoctl->DataBuffer;
        d.open();
        d.ioctl(IOCTL_SCSI_MINIPORT,
                pMyIoctl,
                sizeof(myIoctlBuf),
                pMyIoctl,
                sizeof(myIoctlBuf),
                &dw);
        d.close();

        memcpy(buffer, ident_ctrl, sizeof(ADMIN_IDENTIFY_CONTROLLER));

        return 0;
}

int get_nsid(Device& d)
{
        UCHAR myIoctlBuf[sizeof(NVME_PASS_THROUGH_IOCTL) + sizeof(DWORD)];
        PNVME_PASS_THROUGH_IOCTL     pMyIoctl = (PNVME_PASS_THROUGH_IOCTL)myIoctlBuf;
        DWORD                        dw;
        PDWORD                       pNSID;

        memset(pMyIoctl, 0, sizeof(myIoctlBuf));
        // Set up the SRB IO Control header
        pMyIoctl->SrbIoCtrl.ControlCode = (ULONG)NVME_PASS_THROUGH_NSID;
        memcpy(pMyIoctl->SrbIoCtrl.Signature, NVME_SIG_STR, sizeof(NVME_SIG_STR));
        pMyIoctl->SrbIoCtrl.HeaderLength = (ULONG)sizeof(SRB_IO_CONTROL);
        pMyIoctl->SrbIoCtrl.Timeout = 30;
        pMyIoctl->SrbIoCtrl.Length = sizeof(myIoctlBuf) - sizeof(SRB_IO_CONTROL);
        pMyIoctl->ReturnBufferLen = sizeof(myIoctlBuf);
        pMyIoctl->Direction = NVME_FROM_DEV_TO_HOST;

        d.open();
        d.ioctl(IOCTL_SCSI_MINIPORT,
                pMyIoctl,
                sizeof(myIoctlBuf),
                pMyIoctl,
                sizeof(myIoctlBuf),
                &dw);
        d.close();

        pNSID = (PDWORD)pMyIoctl->DataBuffer;
        return *pNSID;
}


int identify_namespace(Device& d, void* buffer, int buffersize)
{
        UCHAR myIoctlBuf[sizeof(NVME_PASS_THROUGH_IOCTL) +
                sizeof(ADMIN_IDENTIFY_NAMESPACE)];
        PNVME_PASS_THROUGH_IOCTL     pMyIoctl = (PNVME_PASS_THROUGH_IOCTL)myIoctlBuf;
        DWORD                        dw;
        PADMIN_IDENTIFY_COMMAND_DW10 dw10;
        PNVMe_COMMAND                pCmd;
        BOOL                         b;

        if (!buffer || (buffersize < sizeof(ADMIN_IDENTIFY_NAMESPACE))) {
                return -1;
        }

        memset(pMyIoctl, 0, sizeof(myIoctlBuf));

        // Set up the SRB IO Control header
        pMyIoctl->SrbIoCtrl.ControlCode = (ULONG)NVME_PASS_THROUGH_SRB_IO_CODE;
        memcpy(pMyIoctl->SrbIoCtrl.Signature, NVME_SIG_STR, sizeof(NVME_SIG_STR));
        pMyIoctl->SrbIoCtrl.HeaderLength = (ULONG)sizeof(SRB_IO_CONTROL);
        pMyIoctl->SrbIoCtrl.Timeout = 30;
        pMyIoctl->SrbIoCtrl.Length = sizeof(myIoctlBuf) - sizeof(SRB_IO_CONTROL);

        // Set up the NVMe pass through IOCTL buffer
        pCmd = (PNVMe_COMMAND)pMyIoctl->NVMeCmd;
        pCmd->CDW0.OPC = ADMIN_IDENTIFY;
        pCmd->NSID = get_nsid(d);
        dw10 = (PADMIN_IDENTIFY_COMMAND_DW10) & (pCmd->CDW10);
        dw10->CNS = 0;

        pMyIoctl->QueueId = 0; // Admin queue
        pMyIoctl->DataBufferLen = 0;
        pMyIoctl->Direction = NVME_FROM_DEV_TO_HOST;
        pMyIoctl->ReturnBufferLen = sizeof(ADMIN_IDENTIFY_NAMESPACE) + sizeof(NVME_PASS_THROUGH_IOCTL);
        pMyIoctl->VendorSpecific[0] = (DWORD)0;
        pMyIoctl->VendorSpecific[1] = (DWORD)0;
        memset(pMyIoctl->DataBuffer, 0x55, sizeof(ADMIN_IDENTIFY_NAMESPACE));

        d.open();
        d.ioctl(IOCTL_SCSI_MINIPORT,
                pMyIoctl,
                sizeof(myIoctlBuf),
                pMyIoctl,
                sizeof(myIoctlBuf),
                &dw);
        d.close();

        memcpy(buffer, pMyIoctl->DataBuffer, buffersize);

        return 0;
}

int set_xphy_password(Device& d, const char *oldpass, const char *newpass)
{
        UCHAR myIoctlBuf[sizeof(NVME_PASS_THROUGH_IOCTL) +
                         sizeof(PADMIN_SET_PASSWORD)];
        PNVME_PASS_THROUGH_IOCTL pMyIoctl = (PNVME_PASS_THROUGH_IOCTL)myIoctlBuf;
        DWORD dw;
        DWORD dw10;
        PNVMe_COMMAND pCmd;
        PADMIN_SET_PASSWORD SetPassObj = NULL;

        //if (!oldpass || !newpass || (buffersize < sizeof(ADMIN_SET_PASSWORD))) {
        //        return -1;
        //}

        memset(pMyIoctl, 0, sizeof(myIoctlBuf));

        // Set up the SRB IO Control header
        pMyIoctl->SrbIoCtrl.ControlCode = (ULONG)NVME_PASS_THROUGH_SRB_IO_CODE;
        memcpy(pMyIoctl->SrbIoCtrl.Signature, NVME_SIG_STR, sizeof(NVME_SIG_STR));
        pMyIoctl->SrbIoCtrl.HeaderLength = (ULONG)sizeof(SRB_IO_CONTROL);
        pMyIoctl->SrbIoCtrl.Timeout = 30;
        pMyIoctl->Direction = NVME_FROM_HOST_TO_DEV;
        pMyIoctl->SrbIoCtrl.Length = sizeof(myIoctlBuf) - sizeof(SRB_IO_CONTROL);

        // Set up the NVMe pass through IOCTL buffer
        pCmd = (PNVMe_COMMAND)pMyIoctl->NVMeCmd;
        pCmd->CDW0.OPC = FLEXX_VENDOR_OPCODE;
        pCmd->CDW10 = sizeof(ADMIN_SET_PASSWORD);
        pCmd->CDW11 = FLEXX_SETPASS_SUBOPCODE;

        SetPassObj = (PADMIN_SET_PASSWORD)pMyIoctl->DataBuffer;
        memset(SetPassObj, 0x00, sizeof(ADMIN_SET_PASSWORD));

        strcpy((char *)SetPassObj->CurrentPassword, oldpass);
        strcpy((char *)SetPassObj->NewPassword, newpass);

        d.open();
        d.ioctl(IOCTL_SCSI_MINIPORT,
                pMyIoctl,
                sizeof(myIoctlBuf),
                pMyIoctl,
                sizeof(myIoctlBuf),
                &dw);
        d.close();
        return 0;
}

int lock_namespace(Device& d, void* buffer, int buffersize)
{
        UCHAR myIoctlBuf[sizeof(NVME_PASS_THROUGH_IOCTL) +
                sizeof(ADMIN_LOCK_NAMESPACE)];
        PNVME_PASS_THROUGH_IOCTL pMyIoctl = (PNVME_PASS_THROUGH_IOCTL)myIoctlBuf;
        DWORD dw;
        PNVMe_COMMAND pCmd;

        if (!buffer || (buffersize < sizeof(ADMIN_LOCK_NAMESPACE))) {
                return -1;
        }

        memset(pMyIoctl, 0, sizeof(myIoctlBuf));

        // Set up the SRB IO Control header
        pMyIoctl->SrbIoCtrl.ControlCode = (ULONG)NVME_PASS_THROUGH_NSID;
        memcpy(pMyIoctl->SrbIoCtrl.Signature, NVME_SIG_STR, sizeof(NVME_SIG_STR));
        pMyIoctl->SrbIoCtrl.HeaderLength = (ULONG)sizeof(SRB_IO_CONTROL);
        pMyIoctl->SrbIoCtrl.Timeout = 30;
        pMyIoctl->SrbIoCtrl.Length = sizeof(myIoctlBuf) - sizeof(SRB_IO_CONTROL);

        // Set up the NVMe pass through IOCTL buffer
        pCmd = (PNVMe_COMMAND)pMyIoctl->NVMeCmd;
        pCmd->CDW0.OPC = FLEXX_VENDOR_OPCODE;
        pCmd->NSID = get_nsid(d);
        pCmd->CDW10 = sizeof(ADMIN_LOCK_NAMESPACE);
        pCmd->CDW11 = FLEXX_LOCK_NS_SUBOPCODE;

        d.open();
        d.ioctl(IOCTL_SCSI_MINIPORT,
                pMyIoctl,
                sizeof(myIoctlBuf),
                pMyIoctl,
                sizeof(myIoctlBuf),
                &dw);
        d.close();
        return 0;
}

int get_log_page(Device& d, void* buffer, int buffersize, int logpgid)
{
        PNVME_PASS_THROUGH_IOCTL            pMyIoctl; 
        DWORD                               dw;
        PADMIN_GET_LOG_PAGE_COMMAND_DW10    dw10;
        PNVMe_COMMAND                       pCmd;
        INT                                 dwLen = buffersize / 4 - 1;

        // Total size of ioctl will vary depending on log page type and its buffersize, so alloc it.
        pMyIoctl = (PNVME_PASS_THROUGH_IOCTL)new UCHAR[sizeof(NVME_PASS_THROUGH_IOCTL) + buffersize];
        if (pMyIoctl == NULL) {
                return -1;
        }

        memset(pMyIoctl, 0, sizeof(*pMyIoctl));

        // Set up the SRB IO Control header
        pMyIoctl->SrbIoCtrl.ControlCode = (ULONG)NVME_PASS_THROUGH_NSID;
        memcpy(pMyIoctl->SrbIoCtrl.Signature, NVME_SIG_STR, sizeof(NVME_SIG_STR));
        pMyIoctl->SrbIoCtrl.HeaderLength = (ULONG)sizeof(SRB_IO_CONTROL);
        pMyIoctl->SrbIoCtrl.Timeout = 30;
        pMyIoctl->SrbIoCtrl.Length = sizeof(*pMyIoctl) - sizeof(SRB_IO_CONTROL);

        // Set up the NVMe pass through IOCTL buffer
        pCmd = (PNVMe_COMMAND)pMyIoctl->NVMeCmd;
        pCmd->CDW0.OPC = ADMIN_GET_LOG_PAGE;
        pCmd->NSID = get_nsid(d);
        dw10 = (PADMIN_GET_LOG_PAGE_COMMAND_DW10) & (pCmd->CDW10);
        dw10->LID = logpgid;
        dw10->NUMD = dwLen;

        pMyIoctl->QueueId = 0; // Admin queue
        pMyIoctl->DataBufferLen = 0;
        pMyIoctl->Direction = NVME_FROM_DEV_TO_HOST;
        pMyIoctl->ReturnBufferLen = buffersize + sizeof(NVME_PASS_THROUGH_IOCTL);
        pMyIoctl->VendorSpecific[0] = (DWORD)0;
        pMyIoctl->VendorSpecific[1] = (DWORD)0;
        memset(pMyIoctl->DataBuffer, 0x00, buffersize);

        d.open();
        d.ioctl(IOCTL_SCSI_MINIPORT,
                pMyIoctl,
                sizeof(*pMyIoctl),
                pMyIoctl,
                sizeof(*pMyIoctl),
                &dw);
        d.close();

        memcpy(buffer, pMyIoctl->DataBuffer, buffersize);

        delete pMyIoctl;

        return 0;
}

int get_smart_log_page(Device& d, void* buffer, int buffersize)
{
        if (!buffer || (buffersize < sizeof(ADMIN_GET_LOG_PAGE_SMART_HEALTH_INFORMATION_LOG_ENTRY))) {
                return -1;
        }

        return get_log_page(d, buffer, buffersize, SMART_HEALTH_INFORMATION);
}
