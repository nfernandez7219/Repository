#ifndef __RAW_DEVICE_H__
#define __RAW_DEVICE_H__

#include <Windows.h>
#include <stdio.h>

#define MAX_BLOCK_DEVICES       1024
#define MAX_FILENAME_LENGTH     1024


enum device_type {
        device_type_unkown = 0,
        device_type_block,
};

struct TargetType {
        char filename[MAX_FILENAME_LENGTH];
        int typ;
};


class Device
{
public:
        Device(struct TargetType& tgt)
        {
                Target = tgt;
                hdl = INVALID_HANDLE_VALUE;
        }

        void print_name()
        {
                printf("printing: %s\n", Target.filename);
        }

        int open()
        {
                if (hdl == INVALID_HANDLE_VALUE) {
                        hdl = CreateFileA(Target.filename,
                                GENERIC_READ | GENERIC_WRITE,
                                FILE_SHARE_READ | FILE_SHARE_WRITE,
                                NULL,
                                OPEN_EXISTING,
                                FILE_ATTRIBUTE_NORMAL,
                                NULL);
                }
                return (hdl != INVALID_HANDLE_VALUE) ? 0 : -1;
        }

        void close(void)
        {
                if (hdl != INVALID_HANDLE_VALUE) {
                        CloseHandle(hdl);
                        hdl = INVALID_HANDLE_VALUE;
                }
                return;
        }

        int ioctl(const unsigned int request, ...)
        {
                LPVOID inBuffer;
                DWORD inBufferSize;
                LPVOID outBuffer;
                DWORD outBufferSize;
                LPDWORD bytesReturned;
                va_list args;
                BOOL b;

                va_start(args, request);
                inBuffer = va_arg(args, LPVOID);
                inBufferSize = va_arg(args, DWORD);
                outBuffer = va_arg(args, LPVOID);
                outBufferSize = va_arg(args, DWORD);
                bytesReturned = va_arg(args, LPDWORD);
                va_end(args);

                b = DeviceIoControl(hdl,
                        request,
                        inBuffer,
                        inBufferSize,
                        outBuffer,
                        outBufferSize,
                        bytesReturned,
                        NULL);

                return b ? 0 : -1;
        }


protected:
        HANDLE hdl;

        struct TargetType Target;
};


int isType(struct TargetType* tgt, const int typ);

#endif /* __RAW_DEVICE_H__ */

